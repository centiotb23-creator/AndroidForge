package com.challenge.videorank.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.challenge.videorank.ui.screens.DuelScreen
import com.challenge.videorank.ui.screens.HomeScreen
import com.challenge.videorank.ui.screens.RankingScreen
import com.challenge.videorank.viewmodel.GameViewModel

private object Routes {
    const val HOME = "home"
    const val DUEL = "duel"
    const val RANKING = "ranking"
}

@Composable
fun VideoChallengeApp(viewModel: GameViewModel) {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                viewModel = viewModel,
                onPlayDuel = { navController.navigate(Routes.DUEL) },
                onViewRanking = { navController.navigate(Routes.RANKING) }
            )
        }
        composable(Routes.DUEL) {
            DuelScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.RANKING) {
            RankingScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
