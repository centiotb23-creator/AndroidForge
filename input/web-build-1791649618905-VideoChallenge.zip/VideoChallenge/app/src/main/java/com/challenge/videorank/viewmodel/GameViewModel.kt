package com.challenge.videorank.viewmodel

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.challenge.videorank.data.AppDatabase
import com.challenge.videorank.data.VideoEntity
import com.challenge.videorank.util.VideoUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.pow
import kotlin.random.Random

sealed class LevelUpEvent {
    data class Show(val newLevel: Int) : LevelUpEvent()
    object None : LevelUpEvent()
}

/**
 * Drives the whole game: importing videos, picking "duel" pairs, updating an
 * Elo-style difficulty rating whenever the person picks a winner, and tracking
 * XP / level / streak for the game-like feel.
 */
class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getInstance(application).videoDao()

    val videos: StateFlow<List<VideoEntity>> = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _totalXp = MutableStateFlow(0)
    val totalXp: StateFlow<Int> = _totalXp

    private val _streak = MutableStateFlow(0)
    val streak: StateFlow<Int> = _streak

    private val _levelUpEvent = MutableStateFlow<LevelUpEvent>(LevelUpEvent.None)
    val levelUpEvent: StateFlow<LevelUpEvent> = _levelUpEvent

    private val thumbnailCache = mutableMapOf<String, Bitmap?>()

    val level: Int
        get() = 1 + (_totalXp.value / 100)

    val xpIntoLevel: Int
        get() = _totalXp.value % 100

    fun importVideos(uris: List<Uri>) {
        val context = getApplication<Application>()
        viewModelScope.launch {
            var imported = 0
            for (uri in uris) {
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: SecurityException) {
                    // some providers don't support persistable grants; the Uri may still
                    // work for the current session, so we keep going instead of failing.
                }
                val uriString = uri.toString()
                if (dao.countByUri(uriString) > 0) continue
                val meta = VideoUtils.readMeta(context, uri)
                dao.insert(
                    VideoEntity(
                        uri = uriString,
                        displayName = meta.displayName,
                        durationMs = meta.durationMs
                    )
                )
                imported++
            }
            if (imported > 0) {
                addXp(imported * 5)
            }
        }
    }

    suspend fun thumbnailFor(video: VideoEntity): Bitmap? {
        thumbnailCache[video.uri]?.let { return it }
        val context = getApplication<Application>()
        val bmp = VideoUtils.extractThumbnail(context, Uri.parse(video.uri))
        thumbnailCache[video.uri] = bmp
        return bmp
    }

    /** Picks two distinct videos for the next duel, favoring ones with fewer past duels. */
    fun pickDuelPair(): Pair<VideoEntity, VideoEntity>? {
        val list = videos.value
        if (list.size < 2) return null
        val pool = list.sortedBy { it.duels }.take(maxOf(4, list.size / 2))
        val a = pool.random()
        var b = list.random()
        var guard = 0
        while (b.id == a.id && guard < 10) {
            b = list.random()
            guard++
        }
        return if (Random.nextBoolean()) a to b else b to a
    }

    /** Called when the person picks [harder] as the more difficult of the pair. */
    fun resolveDuel(harder: VideoEntity, easier: VideoEntity) {
        viewModelScope.launch {
            val expectedHarder = 1.0 / (1.0 + 10.0.pow((easier.rating - harder.rating) / 400.0))
            val expectedEasier = 1.0 - expectedHarder
            val k = 32.0

            val newHarder = harder.copy(
                rating = harder.rating + k * (1.0 - expectedHarder),
                duels = harder.duels + 1
            )
            val newEasier = easier.copy(
                rating = easier.rating + k * (0.0 - expectedEasier),
                duels = easier.duels + 1
            )
            dao.update(newHarder)
            dao.update(newEasier)

            _streak.value += 1
            addXp(10 + _streak.value.coerceAtMost(5))
        }
    }

    fun skipDuel() {
        _streak.value = 0
    }

    private fun addXp(amount: Int) {
        val oldLevel = level
        _totalXp.value += amount
        val newLevel = level
        if (newLevel > oldLevel) {
            _levelUpEvent.value = LevelUpEvent.Show(newLevel)
        }
    }

    fun consumeLevelUpEvent() {
        _levelUpEvent.value = LevelUpEvent.None
    }
}

class GameViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return GameViewModel(application) as T
    }
}
