package com.challenge.videorank.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.challenge.videorank.data.DifficultyTier
import com.challenge.videorank.ui.theme.NeonCyan
import com.challenge.videorank.ui.theme.NeonOrange
import com.challenge.videorank.ui.theme.NeonPurple

fun Modifier.clickableNoRipple(
    enabled: Boolean,
    interactionSource: MutableInteractionSource,
    onClick: () -> Unit
): Modifier = this.clickable(
    interactionSource = interactionSource,
    indication = null,
    enabled = enabled,
    onClick = onClick
)

@Composable
fun LevelBadge(level: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(64.dp)
            .background(Brush.linearGradient(listOf(NeonPurple, NeonCyan)), CircleShape)
            .border(2.dp, Color.White.copy(alpha = 0.6f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("NIVEL", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
            Text("$level", fontSize = 20.sp, color = Color.White, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
fun XpBar(progressPercent: Int, modifier: Modifier = Modifier) {
    val animatedProgress = remember { Animatable(0f) }
    LaunchedEffect(progressPercent) {
        animatedProgress.animateTo(progressPercent / 100f, animationSpec = tween(600))
    }
    Column(modifier = modifier) {
        LinearProgressIndicator(
            progress = { animatedProgress.value },
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp)),
            color = NeonCyan,
            trackColor = Color.White.copy(alpha = 0.1f)
        )
        Spacer(Modifier.height(2.dp))
        Text("$progressPercent XP / 100", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
    }
}

@Composable
fun TierChip(tier: DifficultyTier, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(tier.color.copy(alpha = 0.18f), RoundedCornerShape(50))
            .border(1.dp, tier.color, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(tier.label, color = tier.color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun StreakBadge(streak: Int, modifier: Modifier = Modifier) {
    if (streak <= 0) return
    Row(
        modifier = modifier
            .background(NeonOrange.copy(alpha = 0.18f), RoundedCornerShape(50))
            .border(1.dp, NeonOrange, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("🔥", fontSize = 14.sp)
        Spacer(Modifier.width(4.dp))
        Text("Racha x$streak", color = NeonOrange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
