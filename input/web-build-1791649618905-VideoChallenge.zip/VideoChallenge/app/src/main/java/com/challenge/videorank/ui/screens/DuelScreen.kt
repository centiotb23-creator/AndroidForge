package com.challenge.videorank.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.challenge.videorank.data.VideoEntity
import com.challenge.videorank.ui.components.StreakBadge
import com.challenge.videorank.ui.theme.BackgroundDark
import com.challenge.videorank.ui.theme.NeonCyan
import com.challenge.videorank.ui.theme.NeonPink
import com.challenge.videorank.util.VideoUtils
import com.challenge.videorank.viewmodel.GameViewModel
import com.challenge.videorank.viewmodel.LevelUpEvent
import kotlinx.coroutines.delay

@Composable
fun DuelScreen(viewModel: GameViewModel, onBack: () -> Unit) {
    val videos by viewModel.videos.collectAsState()
    val streak by viewModel.streak.collectAsState()
    val levelUpEvent by viewModel.levelUpEvent.collectAsState()

    var pair by remember { mutableStateOf<Pair<VideoEntity, VideoEntity>?>(null) }
    var initialized by remember { mutableStateOf(false) }
    var winnerId by remember { mutableStateOf<Long?>(null) }
    var showLevelUp by remember { mutableStateOf(false) }
    var levelUpValue by remember { mutableStateOf(1) }

    // Seed the first pair as soon as the video list is loaded from the DB.
    LaunchedEffect(videos) {
        if (!initialized && videos.size >= 2) {
            pair = viewModel.pickDuelPair()
            initialized = true
        }
    }

    LaunchedEffect(levelUpEvent) {
        val event = levelUpEvent
        if (event is LevelUpEvent.Show) {
            levelUpValue = event.newLevel
            showLevelUp = true
            delay(1600)
            showLevelUp = false
            viewModel.consumeLevelUpEvent()
        }
    }

    fun nextRound() {
        winnerId = null
        pair = viewModel.pickDuelPair()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BackgroundDark, Color(0xFF1A1033))))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = Color.White)
                }
                Spacer(Modifier.width(8.dp))
                Text("MODO DUELO", color = NeonCyan, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                Spacer(Modifier.weight(1f))
                StreakBadge(streak = streak)
            }

            Spacer(Modifier.height(12.dp))

            val currentPair = pair
            if (currentPair == null || videos.size < 2) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Necesitas al menos 2 vídeos para jugar",
                        color = Color.White.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                val (a, b) = currentPair

                Text(
                    "¿Cuál es más DIFÍCIL?",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                )

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    DuelCard(
                        video = a,
                        isWinner = winnerId == a.id,
                        isLoser = winnerId != null && winnerId != a.id,
                        viewModel = viewModel,
                        modifier = Modifier.weight(1f),
                        onChoose = {
                            if (winnerId == null) {
                                winnerId = a.id
                                viewModel.resolveDuel(harder = a, easier = b)
                            }
                        }
                    )
                    DuelCard(
                        video = b,
                        isWinner = winnerId == b.id,
                        isLoser = winnerId != null && winnerId != b.id,
                        viewModel = viewModel,
                        modifier = Modifier.weight(1f),
                        onChoose = {
                            if (winnerId == null) {
                                winnerId = b.id
                                viewModel.resolveDuel(harder = b, easier = a)
                            }
                        }
                    )
                }

                LaunchedEffect(winnerId) {
                    if (winnerId != null) {
                        delay(700)
                        nextRound()
                    }
                }

                TextButton(
                    onClick = {
                        viewModel.skipDuel()
                        nextRound()
                    },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text("Omitir pareja", color = Color.White.copy(alpha = 0.6f))
                }
            }
        }

        AnimatedVisibility(
            visible = showLevelUp,
            modifier = Modifier.align(Alignment.Center)
        ) {
            LevelUpOverlay(level = levelUpValue)
        }
    }
}

@Composable
private fun DuelCard(
    video: VideoEntity,
    isWinner: Boolean,
    isLoser: Boolean,
    viewModel: GameViewModel,
    modifier: Modifier = Modifier,
    onChoose: () -> Unit
) {
    var thumbnail by remember(video.id) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(video.id) {
        thumbnail = viewModel.thumbnailFor(video)
    }

    val scale by animateFloatAsState(
        targetValue = if (isWinner) 1.03f else if (isLoser) 0.95f else 1f,
        animationSpec = tween(400),
        label = "cardScale"
    )
    val alpha by animateFloatAsState(
        targetValue = if (isLoser) 0.4f else 1f,
        animationSpec = tween(400),
        label = "cardAlpha"
    )
    val borderColor = if (isWinner) NeonCyan else Color.White.copy(alpha = 0.15f)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .scale(scale)
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF1A1730).copy(alpha = alpha))
            .border(2.dp, borderColor, RoundedCornerShape(20.dp))
            .clickable(enabled = !isWinner && !isLoser) { onChoose() }
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.Black)
            ) {
                if (thumbnail != null) {
                    Image(
                        bitmap = thumbnail!!.asImageBitmap(),
                        contentDescription = video.displayName,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = NeonPink, modifier = Modifier.size(28.dp))
                    }
                }
                if (isWinner) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(NeonCyan, RoundedCornerShape(50))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("+XP", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    video.displayName,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    maxLines = 1
                )
                Text(
                    VideoUtils.formatDuration(video.durationMs),
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun LevelUpOverlay(level: Int) {
    val infiniteTransition = rememberInfiniteTransition(label = "levelUpPulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(500), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(
        modifier = Modifier
            .scale(pulse)
            .background(Brush.radialGradient(listOf(NeonPink, Color.Transparent)), RoundedCornerShape(24.dp))
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("¡NIVEL SUPERADO!", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            Text("Nivel $level", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 36.sp)
        }
    }
}
