package com.challenge.videorank.data

import androidx.compose.ui.graphics.Color
import com.challenge.videorank.ui.theme.TierEasy
import com.challenge.videorank.ui.theme.TierEpic
import com.challenge.videorank.ui.theme.TierHard
import com.challenge.videorank.ui.theme.TierLegendary
import com.challenge.videorank.ui.theme.TierNormal

enum class DifficultyTier(val label: String, val color: Color) {
    EASY("Fácil", TierEasy),
    NORMAL("Normal", TierNormal),
    HARD("Difícil", TierHard),
    EPIC("Épico", TierEpic),
    LEGENDARY("Legendario", TierLegendary)
}

fun tierForRating(rating: Double): DifficultyTier = when {
    rating < 1100 -> DifficultyTier.EASY
    rating < 1250 -> DifficultyTier.NORMAL
    rating < 1400 -> DifficultyTier.HARD
    rating < 1550 -> DifficultyTier.EPIC
    else -> DifficultyTier.LEGENDARY
}
