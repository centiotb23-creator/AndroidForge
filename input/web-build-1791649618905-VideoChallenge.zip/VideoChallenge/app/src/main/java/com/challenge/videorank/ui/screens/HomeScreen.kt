package com.challenge.videorank.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.challenge.videorank.ui.components.LevelBadge
import com.challenge.videorank.ui.components.StreakBadge
import com.challenge.videorank.ui.components.XpBar
import com.challenge.videorank.ui.components.clickableNoRipple
import com.challenge.videorank.ui.theme.BackgroundDark
import com.challenge.videorank.ui.theme.NeonCyan
import com.challenge.videorank.ui.theme.NeonPink
import com.challenge.videorank.ui.theme.NeonPurple
import com.challenge.videorank.ui.theme.SurfaceDark
import com.challenge.videorank.viewmodel.GameViewModel

@Composable
fun HomeScreen(
    viewModel: GameViewModel,
    onPlayDuel: () -> Unit,
    onViewRanking: () -> Unit
) {
    val videos by viewModel.videos.collectAsState()
    val streak by viewModel.streak.collectAsState()
    viewModel.totalXp.collectAsState().value // observe so level/xp recompute on change

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) viewModel.importVideos(uris)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BackgroundDark, Color(0xFF1A1033))))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Text(
                "VIDEO CHALLENGE",
                color = NeonCyan,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                "Clasifica tus vídeos del más fácil al más difícil",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 13.sp
            )

            Spacer(Modifier.height(24.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                LevelBadge(level = viewModel.level)
                Spacer(Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    XpBar(progressPercent = viewModel.xpIntoLevel)
                    Spacer(Modifier.height(6.dp))
                    StreakBadge(streak = streak)
                }
            }

            Spacer(Modifier.height(32.dp))

            Text(
                "${videos.size} vídeos en tu colección",
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp
            )

            Spacer(Modifier.height(16.dp))

            GameButton(
                text = "📥  Importar vídeos",
                gradient = Brush.horizontalGradient(listOf(NeonPurple, NeonCyan)),
                onClick = { importLauncher.launch(arrayOf("video/*")) }
            )

            Spacer(Modifier.height(12.dp))

            GameButton(
                text = "⚔️  Modo Duelo",
                gradient = Brush.horizontalGradient(listOf(NeonPink, NeonPurple)),
                enabled = videos.size >= 2,
                onClick = onPlayDuel
            )
            if (videos.size < 2) {
                Text(
                    "Importa al menos 2 vídeos para empezar a jugar",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                )
            }

            Spacer(Modifier.height(12.dp))

            GameButton(
                text = "🏆  Ver Ranking",
                gradient = Brush.horizontalGradient(listOf(Color(0xFFFFD54F), Color(0xFFFF8A65))),
                enabled = videos.isNotEmpty(),
                onClick = onViewRanking
            )
        }
    }
}

@Composable
private fun GameButton(
    text: String,
    gradient: Brush,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "buttonScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) gradient else Brush.horizontalGradient(listOf(SurfaceDark, SurfaceDark)))
            .clickableNoRipple(enabled, interactionSource, onClick)
            .padding(vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (enabled) Color.White else Color.White.copy(alpha = 0.4f),
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
    }
}
