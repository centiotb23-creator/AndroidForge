package com.challenge.videorank.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One imported video. [rating] is an Elo-style difficulty score: it starts at 1200
 * and moves up or down every time the video wins or loses a "duel" against another
 * video in Duel Mode. Sorting all videos by [rating] gives the easy-to-hard ranking.
 */
@Entity(tableName = "videos")
data class VideoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val displayName: String,
    val durationMs: Long,
    val rating: Double = 1200.0,
    val duels: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
