# Video Challenge 🎮

App Android (Kotlin + Jetpack Compose) para importar los vídeos que ya tienes
descargados en el móvil y clasificarlos de **más fácil a más difícil** jugando,
como si fuera un videojuego de duelos.

## Cómo funciona

1. **Importar vídeos**: pulsa "Importar vídeos" y elige, con el selector de
   archivos del propio Android, los vídeos que tengas descargados (no se piden
   permisos de almacenamiento: se usa el selector de documentos del sistema,
   que da acceso directo y persistente solo a los archivos que elijas).
2. **Modo Duelo** ⚔️: la app te enfrenta dos vídeos al azar y te pregunta
   *"¿Cuál es más difícil?"*. Tocas el que creas más difícil, ganas XP, subes
   de racha 🔥 y el sistema ajusta la dificultad de cada vídeo con un algoritmo
   tipo Elo (el mismo tipo de puntuación que usa el ajedrez), igual que si
   fueran "jugadores" compitiendo entre sí.
3. **Ranking** 🏆: lista ordenada automáticamente de más fácil a más difícil,
   con insignias de nivel de dificultad (Fácil, Normal, Difícil, Épico,
   Legendario) y miniaturas generadas directamente del propio vídeo.

Cuantos más duelos juegues, más preciso se vuelve el ranking.

## Elementos de videojuego incluidos

- Nivel y barra de XP animada, con overlay de "¡Nivel superado!" al subir.
- Rachas de aciertos con contador de fuego.
- Tarjetas de duelo con animaciones de escala/opacidad al elegir ganador.
- Paleta neón oscura (cian, morado, rosa) con degradados, pensada para que se
  sienta como una interfaz de juego y no como un gestor de archivos.
- Insignias de "rareza" (tipo loot de videojuego) para marcar la dificultad.

## Abrir el proyecto

1. Instala **Android Studio** (versión Koala 2024.1 o posterior).
2. `Open` → selecciona la carpeta `VideoChallenge` (la que contiene este
   `README.md`).
3. Deja que Android Studio sincronice Gradle. Si te pregunta por el
   "Gradle Wrapper" (falta el `.jar` del wrapper, que no se incluye aquí),
   acepta que Android Studio lo regenere o use su propio Gradle incluido —
   es automático, no hace falta hacer nada manualmente.
4. Conecta un móvil (Android 8.0 / API 26 o superior) con la depuración USB
   activada, o usa un emulador, y pulsa ▶️ Run.

No se necesita ninguna cuenta ni servidor: todo (vídeos importados, XP,
puntuaciones de dificultad) se guarda localmente en el propio dispositivo con
una base de datos Room.

## Estructura del proyecto

```
app/src/main/java/com/challenge/videorank/
├── MainActivity.kt
├── data/            → Entidad Room, DAO, base de datos, niveles de dificultad
├── viewmodel/        → Lógica de juego: importar, duelos, Elo, XP/nivel/racha
├── util/              → Lectura de metadatos y miniaturas de vídeo
└── ui/
    ├── theme/         → Colores, tipografía, tema oscuro neón
    ├── components/    → Insignias, barra de XP, chips de dificultad
    ├── screens/        → HomeScreen, DuelScreen, RankingScreen
    └── VideoChallengeApp.kt → Navegación
```

## Posibles mejoras futuras

- Reproducir el vídeo (no solo la miniatura) al mantener pulsada la tarjeta.
- Categorías/etiquetas personalizadas además de la dificultad.
- Confeti o partículas más elaboradas al subir de nivel.
- Compartir el ranking como imagen.
- Sonidos de "combo" al encadenar rachas.

---

Este proyecto se generó como código fuente completo de Android Studio; no se
ha podido compilar un APK dentro de este entorno (no incluye el SDK de
Android), pero el código está escrito y revisado cuidadosamente para
compilar tal cual al abrirlo en Android Studio.
