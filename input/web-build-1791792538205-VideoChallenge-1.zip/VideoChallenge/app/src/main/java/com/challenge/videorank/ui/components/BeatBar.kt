package com.challenge.videorank.ui.components

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.challenge.videorank.audio.BeatMap
import com.challenge.videorank.audio.PlaybackClock
import com.challenge.videorank.audio.atOrBefore
import com.challenge.videorank.audio.from
import kotlin.math.abs
import kotlin.math.sin

/** Where the fixed "hit circle" sits, as a fraction of the bar's width — dead center. */
private const val HIT_X_FRACTION = 0.5f

/**
 * How long a note takes to cross from the right edge to the hit circle. Kept
 * long on purpose: slow and smooth is what makes it readable. It still
 * shortens a little at higher levels, which is one of the two difficulty
 * levers (the other is which beat grid gets used — see [gridFor]).
 */
private fun approachMsFor(level: Int): Long = (2500L - level * 130L).coerceIn(1150L, 2500L)

/** How fast a note snaps away once it has passed the hit circle — short and sharp on purpose. */
private const val EXIT_MS = 130L

/** How many upcoming grid points are considered per frame; excess ones are filtered by lead time. */
private const val FETCH_COUNT = 14

/**
 * Picks which of the beat map's nested grids to play against: the main pulse
 * for early levels (calm, one dot per beat), the eighth-note grid in the
 * middle (twice as dense), and the sixteenth-note grid for the hardest
 * levels (four times as dense) — each one a real subdivision of that song's
 * actual tempo, never arbitrary.
 */
private fun gridFor(beatMap: BeatMap, level: Int): LongArray = when {
    level <= 3 -> beatMap.quarterBeatsMs
    level <= 7 -> beatMap.eighthBeatsMs
    else -> beatMap.sixteenthBeatsMs
}

private fun easeOutCubic(t: Float): Float {
    val inv = 1f - t
    return 1f - inv * inv * inv
}

/**
 * A rhythm-game-style bar driven by a real, precomputed tempo analysis of
 * the video's own audio ([beatMap]): a note eases in slowly and smoothly
 * from the right toward the fixed hit circle in the middle — timed to arrive
 * exactly on a real beat of that song's estimated tempo — then snaps away
 * quickly once it's passed, so the "before" and "after" read very
 * differently and the hit moment stays unambiguous.
 *
 * The beat grid itself is quantized to the song's actual tempo (not raw,
 * noisy onsets), so it forms a steady, learnable sequence the player can
 * settle into, the same way a real rhythm game's chart does — while still
 * following that specific song and changing with [level] (see [gridFor] and
 * [approachMsFor]).
 *
 * Falls back to a calm decorative pulse if [beatMap] is null (analysis
 * failed, still running, or the clip has no usable audio track).
 */
@Composable
fun BeatBar(
    beatMap: BeatMap?,
    playbackClock: PlaybackClock,
    level: Int,
    modifier: Modifier = Modifier
) {
    var nowElapsed by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var hitFlash by remember { mutableFloatStateOf(0f) }
    var lastFlashedOnset by remember { mutableLongStateOf(-1L) }
    val fallback = remember { FallbackRhythm() }

    val approachMs = approachMsFor(level)
    val grid = beatMap?.let { gridFor(it, level) }

    LaunchedEffect(beatMap, level) {
        while (true) {
            withFrameMillis { }
            nowElapsed = SystemClock.elapsedRealtime()

            if (beatMap == null) fallback.tick(nowElapsed)

            val positionMs = if (beatMap != null) {
                playbackClock.estimatedPositionMs().coerceIn(0L, beatMap.durationMs.coerceAtLeast(1L))
            } else {
                fallback.positionMs
            }

            val justHit = grid?.atOrBefore(positionMs) ?: fallback.onsetAtOrBefore(positionMs)
            if (justHit != null && justHit != lastFlashedOnset && positionMs - justHit < 110L) {
                lastFlashedOnset = justHit
                hitFlash = 1f
            }
            hitFlash = (hitFlash - 0.07f).coerceAtLeast(0f)
        }
    }

    val idlePulse = 0.5f + 0.5f * sin(nowElapsed / 260f)

    Canvas(modifier = modifier.fillMaxSize()) {
        val hitX = size.width * HIT_X_FRACTION
        val centerY = size.height / 2f

        val positionMs = if (beatMap != null) {
            playbackClock.estimatedPositionMs().coerceIn(0L, beatMap.durationMs.coerceAtLeast(1L))
        } else {
            fallback.positionMs
        }

        // Background waveform: a real trace of this track's own loudness,
        // centered on "now" — the left half is the recent past, the right
        // half previews what's coming, both read straight from the analysis.
        val halfWindowMs = 2200L
        val hop = 18.dp.toPx()
        var x = 0f
        while (x <= size.width) {
            val sampleAt = positionMs - halfWindowMs + ((x / size.width) * (2 * halfWindowMs)).toLong()
            val amplitude = if (beatMap != null) {
                if (sampleAt < 0 || sampleAt > beatMap.durationMs) 0f else beatMap.intensityAt(sampleAt)
            } else {
                fallback.intensityAt(sampleAt)
            }
            val h = (amplitude.coerceIn(0f, 1f) * size.height * 0.4f).coerceAtLeast(2f)
            val distanceFromHit = abs(x - hitX) / size.width
            val alpha = (0.5f - distanceFromHit * 0.4f).coerceIn(0.12f, 0.5f)
            drawLine(
                color = Color(0xFFE056C4).copy(alpha = alpha),
                start = Offset(x, centerY - h / 2f),
                end = Offset(x, centerY + h / 2f),
                strokeWidth = (hop * 0.5f).coerceAtLeast(1f)
            )
            x += hop
        }

        // Playhead marker through the whole lane.
        drawLine(
            color = Color.White.copy(alpha = 0.18f),
            start = Offset(hitX, 0f),
            end = Offset(hitX, size.height),
            strokeWidth = 1.5.dp.toPx()
        )

        // Notes against the song's real, tempo-quantized beat grid: a calm,
        // eased approach from the right that arrives exactly on each beat,
        // then a quick snap-away once it's passed.
        val upcoming = grid?.from(positionMs, FETCH_COUNT) ?: fallback.onsetsFrom(positionMs, FETCH_COUNT)
        val justPassed = grid?.atOrBefore(positionMs) ?: fallback.onsetAtOrBefore(positionMs)

        val allNotes = buildList {
            if (justPassed != null) add(justPassed)
            addAll(upcoming)
        }.distinct()

        for (onsetAt in allNotes) {
            val timeToHit = onsetAt - positionMs
            val cx: Float
            val alpha: Float
            val radius: Float
            if (timeToHit >= 0) {
                if (timeToHit > approachMs) continue
                val linear = (1f - timeToHit.toFloat() / approachMs).coerceIn(0f, 1f)
                val eased = easeOutCubic(linear)
                cx = size.width - eased * (size.width - hitX)
                alpha = (0.35f + 0.65f * eased)
                radius = 7.dp.toPx() * (0.75f + 0.25f * eased)
            } else {
                val sincePassed = -timeToHit
                if (sincePassed > EXIT_MS) continue
                val progress = (sincePassed.toFloat() / EXIT_MS).coerceIn(0f, 1f)
                cx = hitX - progress * hitX * 0.6f
                alpha = (1f - progress) * (1f - progress) // snaps out fast
                radius = 7.dp.toPx() * (1f - 0.35f * progress)
            }
            drawCircle(
                color = Color(0xFF00E5FF).copy(alpha = alpha.coerceIn(0f, 1f)),
                radius = radius,
                center = Offset(cx, centerY)
            )
        }

        // The hit circle: a steady idle sway, plus a sharp flash exactly when
        // a real beat lands.
        val baseRadius = 11.dp.toPx()
        val hitRadius = baseRadius * (1f + idlePulse * 0.12f + hitFlash * 0.55f)
        val hitColor = Color(0xFFFF4D8D)

        if (hitFlash > 0.05f) {
            drawCircle(
                color = hitColor.copy(alpha = hitFlash * 0.35f),
                radius = hitRadius + 13.dp.toPx() * hitFlash,
                center = Offset(hitX, centerY)
            )
        }
        drawCircle(color = hitColor.copy(alpha = 0.9f), radius = hitRadius, center = Offset(hitX, centerY))
        drawCircle(
            color = Color.White.copy(alpha = 0.6f + hitFlash * 0.4f),
            radius = hitRadius,
            center = Offset(hitX, centerY),
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}

/**
 * Decorative-only stand-in used when a video has no usable [BeatMap] (still
 * analyzing, or no audio track at all): a gentle, clearly non-random sway so
 * the bar never looks frozen or broken while real data isn't available.
 */
private class FallbackRhythm {
    var positionMs: Long = 0L
        private set
    private var lastAt = SystemClock.elapsedRealtime()
    private val intervalMs = 700L

    fun tick(nowElapsed: Long) {
        positionMs += (nowElapsed - lastAt)
        lastAt = nowElapsed
    }

    fun intensityAt(ms: Long): Float = 0.18f + 0.1f * sin(ms / 380.0).toFloat()

    fun onsetAtOrBefore(ms: Long): Long? {
        val idx = ms / intervalMs
        return if (idx < 0) null else idx * intervalMs
    }

    fun onsetsFrom(ms: Long, count: Int): List<Long> {
        val start = (ms / intervalMs + 1) * intervalMs
        return (0 until count).map { start + it * intervalMs }
    }
}
