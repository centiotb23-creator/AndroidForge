package com.challenge.videorank.ui.components

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.challenge.videorank.audio.BeatMap
import com.challenge.videorank.audio.PlaybackClock
import com.challenge.videorank.audio.atOrBefore
import com.challenge.videorank.audio.from
import kotlin.math.abs
import kotlin.math.sin

/** Where the fixed "hit circle" sits, as a fraction of the bar's width — dead center. */
private const val HIT_X_FRACTION = 0.5f

/** How many beats of runway to show ahead of the hit circle — calm and readable. */
private const val LEAD_BEATS = 2.3f

/** The runway is still clamped to a sane range, for silent/degenerate edge cases. */
private const val MIN_APPROACH_MS = 900L
private const val MAX_APPROACH_MS = 2600L

/** Fallback runway used only while there's no grid context yet (very start of a track). */
private const val DEFAULT_APPROACH_MS = 1500L

/** How fast a note snaps away once it has passed the hit circle — short and sharp on purpose. */
private const val EXIT_MS = 130L

/** How many upcoming grid points are fetched per frame — generous, cheap to draw. */
private const val FETCH_COUNT = 24

/**
 * How much runway (in ms) a note needs, based on the *real, local* spacing
 * between this song's own beats around [positionMs] — not a fixed number and
 * not anything tied to the challenge level. A fast passage naturally gets a
 * short runway (beats are close together); a slow or sparse passage
 * naturally gets a longer one. This is what keeps the bar's pacing honest to
 * whatever is actually playing instead of following an artificial curve.
 */
private fun localApproachMs(grid: LongArray?, positionMs: Long): Long {
    if (grid == null) return DEFAULT_APPROACH_MS
    val prev = grid.atOrBefore(positionMs)
    val nextTwo = grid.from(positionMs, 2)
    val period = when {
        nextTwo.size >= 2 -> nextTwo[1] - nextTwo[0]
        prev != null && nextTwo.isNotEmpty() -> nextTwo[0] - prev
        else -> return DEFAULT_APPROACH_MS
    }
    return (period * LEAD_BEATS).toLong().coerceIn(MIN_APPROACH_MS, MAX_APPROACH_MS)
}

/**
 * A rhythm-game-style bar driven by a real, precomputed tempo analysis of
 * the video's own audio ([beatMap]): one dot per real beat of that song, with
 * no artificial density added on top and nothing tied to the challenge
 * level — if the music is fast, the dots are close together; if it's slow or
 * sparse, they're far apart; if the track is actually silent, no dots appear
 * there at all. Each note's approach speed is derived from the real local
 * beat spacing around it (see [localApproachMs]), so a busy section and a
 * quiet one each feel correctly paced rather than uniform.
 *
 * The whole upcoming sequence that falls inside that runway is already laid
 * out across the strip at once — not spawned one at a time — and slides left
 * at a steady pace, so the player can see what's coming well before it
 * arrives. Once a note reaches the fixed hit circle in the middle it snaps
 * away quickly, so the hit moment stays unambiguous.
 *
 * Falls back to a calm decorative pulse if [beatMap] is null (analysis
 * failed, still running, or the clip has no usable audio track).
 */
@Composable
fun BeatBar(
    beatMap: BeatMap?,
    playbackClock: PlaybackClock,
    modifier: Modifier = Modifier
) {
    var nowElapsed by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var hitFlash by remember { mutableFloatStateOf(0f) }
    var lastFlashedOnset by remember { mutableLongStateOf(-1L) }
    val fallback = remember { FallbackRhythm() }

    val grid = beatMap?.beatsMs

    LaunchedEffect(beatMap) {
        while (true) {
            withFrameMillis { }
            nowElapsed = SystemClock.elapsedRealtime()

            if (beatMap == null) fallback.tick(nowElapsed)

            val positionMs = if (beatMap != null) {
                playbackClock.estimatedPositionMs().coerceIn(0L, beatMap.durationMs.coerceAtLeast(1L))
            } else {
                fallback.positionMs
            }

            val justHit = grid?.atOrBefore(positionMs) ?: fallback.onsetAtOrBefore(positionMs)
            if (justHit != null && justHit != lastFlashedOnset && positionMs - justHit < 110L) {
                lastFlashedOnset = justHit
                hitFlash = 1f
            }
            hitFlash = (hitFlash - 0.07f).coerceAtLeast(0f)
        }
    }

    val idlePulse = 0.5f + 0.5f * sin(nowElapsed / 260f)

    Canvas(modifier = modifier.fillMaxSize()) {
        val hitX = size.width * HIT_X_FRACTION
        val centerY = size.height / 2f

        val positionMs = if (beatMap != null) {
            playbackClock.estimatedPositionMs().coerceIn(0L, beatMap.durationMs.coerceAtLeast(1L))
        } else {
            fallback.positionMs
        }

        // Background waveform: a real trace of this track's own loudness,
        // centered on "now" — the left half is the recent past, the right
        // half previews what's coming, both read straight from the analysis.
        val halfWindowMs = 2200L
        val hop = 18.dp.toPx()
        var x = 0f
        while (x <= size.width) {
            val sampleAt = positionMs - halfWindowMs + ((x / size.width) * (2 * halfWindowMs)).toLong()
            val amplitude = if (beatMap != null) {
                if (sampleAt < 0 || sampleAt > beatMap.durationMs) 0f else beatMap.intensityAt(sampleAt)
            } else {
                fallback.intensityAt(sampleAt)
            }
            val h = (amplitude.coerceIn(0f, 1f) * size.height * 0.4f).coerceAtLeast(2f)
            val distanceFromHit = abs(x - hitX) / size.width
            val alpha = (0.5f - distanceFromHit * 0.4f).coerceIn(0.12f, 0.5f)
            drawLine(
                color = Color(0xFFE056C4).copy(alpha = alpha),
                start = Offset(x, centerY - h / 2f),
                end = Offset(x, centerY + h / 2f),
                strokeWidth = (hop * 0.5f).coerceAtLeast(1f)
            )
            x += hop
        }

        // Playhead marker through the whole lane.
        drawLine(
            color = Color.White.copy(alpha = 0.18f),
            start = Offset(hitX, 0f),
            end = Offset(hitX, size.height),
            strokeWidth = 1.5.dp.toPx()
        )

        // Notes against the song's real, tempo-quantized beat grid. Each
        // note's own runway comes from the real local beat spacing right
        // around it, so the pacing itself tracks the music, not a level.
        val upcoming = grid?.from(positionMs, FETCH_COUNT) ?: fallback.onsetsFrom(positionMs, FETCH_COUNT)
        val justPassed = grid?.atOrBefore(positionMs) ?: fallback.onsetAtOrBefore(positionMs)

        val allNotes = buildList {
            if (justPassed != null) add(justPassed)
            addAll(upcoming)
        }.distinct()

        for (onsetAt in allNotes) {
            val timeToHit = onsetAt - positionMs
            val cx: Float
            val alpha: Float
            val radius: Float
            if (timeToHit >= 0) {
                val approachMs = localApproachMs(grid, onsetAt)
                if (timeToHit > approachMs) continue
                // Pure constant-speed mapping: every upcoming note already sits at
                // its correct spot the instant it enters its own runway, so the
                // whole queue reads as one steady strip sliding left — not notes
                // individually fading or easing into existence.
                val linear = (1f - timeToHit.toFloat() / approachMs).coerceIn(0f, 1f)
                cx = size.width - linear * (size.width - hitX)
                alpha = 0.88f
                radius = 7.dp.toPx()
            } else {
                val sincePassed = -timeToHit
                if (sincePassed > EXIT_MS) continue
                val progress = (sincePassed.toFloat() / EXIT_MS).coerceIn(0f, 1f)
                cx = hitX - progress * hitX * 0.6f
                alpha = (1f - progress) * (1f - progress) // snaps out fast
                radius = 7.dp.toPx() * (1f - 0.35f * progress)
            }
            drawCircle(
                color = Color(0xFF00E5FF).copy(alpha = alpha.coerceIn(0f, 1f)),
                radius = radius,
                center = Offset(cx, centerY)
            )
        }

        // The hit circle: a steady idle sway, plus a sharp flash exactly when
        // a real beat lands.
        val baseRadius = 11.dp.toPx()
        val hitRadius = baseRadius * (1f + idlePulse * 0.12f + hitFlash * 0.55f)
        val hitColor = Color(0xFFFF4D8D)

        if (hitFlash > 0.05f) {
            drawCircle(
                color = hitColor.copy(alpha = hitFlash * 0.35f),
                radius = hitRadius + 13.dp.toPx() * hitFlash,
                center = Offset(hitX, centerY)
            )
        }
        drawCircle(color = hitColor.copy(alpha = 0.9f), radius = hitRadius, center = Offset(hitX, centerY))
        drawCircle(
            color = Color.White.copy(alpha = 0.6f + hitFlash * 0.4f),
            radius = hitRadius,
            center = Offset(hitX, centerY),
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}

/**
 * Decorative-only stand-in used when a video has no usable [BeatMap] (still
 * analyzing, or no audio track at all): a gentle, clearly non-random sway so
 * the bar never looks frozen or broken while real data isn't available.
 */
private class FallbackRhythm {
    var positionMs: Long = 0L
        private set
    private var lastAt = SystemClock.elapsedRealtime()
    private val intervalMs = 700L

    fun tick(nowElapsed: Long) {
        positionMs += (nowElapsed - lastAt)
        lastAt = nowElapsed
    }

    fun intensityAt(ms: Long): Float = 0.18f + 0.1f * sin(ms / 380.0).toFloat()

    fun onsetAtOrBefore(ms: Long): Long? {
        val idx = ms / intervalMs
        return if (idx < 0) null else idx * intervalMs
    }

    fun onsetsFrom(ms: Long, count: Int): List<Long> {
        val start = (ms / intervalMs + 1) * intervalMs
        return (0 until count).map { start + it * intervalMs }
    }
}
