package com.challenge.videorank.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.challenge.videorank.ui.theme.LevelEasyColor
import com.challenge.videorank.ui.theme.LevelHardColor
import com.challenge.videorank.viewmodel.TOTAL_LEVELS

fun Modifier.clickableNoRipple(
    enabled: Boolean,
    interactionSource: MutableInteractionSource,
    onClick: () -> Unit
): Modifier = this.clickable(
    interactionSource = interactionSource,
    indication = null,
    enabled = enabled,
    onClick = onClick
)

/** Interpolates from green (level 1, easiest) to red (level 10, hardest). */
fun colorForLevel(level: Int): Color {
    val fraction = ((level - 1).coerceIn(0, TOTAL_LEVELS - 1)).toFloat() / (TOTAL_LEVELS - 1)
    return lerp(LevelEasyColor, LevelHardColor, fraction)
}
