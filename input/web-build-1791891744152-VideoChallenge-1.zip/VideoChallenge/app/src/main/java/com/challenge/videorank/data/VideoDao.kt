package com.challenge.videorank.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {

    @Query("SELECT * FROM videos ORDER BY createdAt ASC")
    fun observeAll(): Flow<List<VideoEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(video: VideoEntity): Long

    @Query("SELECT COUNT(*) FROM videos WHERE uri = :uri")
    suspend fun countByUri(uri: String): Int

    @Update
    suspend fun update(video: VideoEntity)

    @Query("DELETE FROM videos WHERE id = :id")
    suspend fun delete(id: Long)
}
