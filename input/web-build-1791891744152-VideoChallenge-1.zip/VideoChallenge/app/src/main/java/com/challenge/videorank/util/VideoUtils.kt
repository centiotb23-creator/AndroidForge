package com.challenge.videorank.util

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object VideoUtils {

    data class VideoMeta(val displayName: String, val durationMs: Long)

    suspend fun readMeta(context: Context, uri: Uri): VideoMeta = withContext(Dispatchers.IO) {
        var name = "Vídeo"
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0 && cursor.moveToFirst()) {
                    name = cursor.getString(nameIndex) ?: name
                }
            }
        } catch (e: Exception) {
            // keep default name
        }

        var duration = 0L
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            duration = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            // keep duration 0, video may still be playable
        } finally {
            retriever.release()
        }
        VideoMeta(name, duration)
    }

    suspend fun extractThumbnail(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            retriever.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.frameAtTime
        } catch (e: Exception) {
            null
        } finally {
            retriever.release()
        }
    }

    /**
     * Grabs a handful of frames spread across the video, for a GTA-style loading
     * screen that cross-fades through stills of what's coming up next.
     */
    suspend fun extractFrames(context: Context, uri: Uri, count: Int = 5): List<Bitmap> =
        withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            val frames = mutableListOf<Bitmap>()
            try {
                retriever.setDataSource(context, uri)
                val durationMs = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L

                if (durationMs <= 0) {
                    retriever.frameAtTime?.let { frames.add(it) }
                } else {
                    val stepUs = (durationMs * 1000L) / (count + 1)
                    for (i in 1..count) {
                        val frame = retriever.getFrameAtTime(
                            stepUs * i,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                        )
                        if (frame != null) frames.add(frame)
                    }
                }
            } catch (e: Exception) {
                // Return whatever frames were already gathered; the UI falls back to
                // a plain gradient if the list ends up empty.
            } finally {
                retriever.release()
            }
            frames
        }

    fun formatDuration(ms: Long): String {
        if (ms <= 0) return "--:--"
        val totalSeconds = ms / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return "%d:%02d".format(minutes, seconds)
    }
}
