package com.challenge.videorank.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundDark = Color(0xFF0D0B1E)
val SurfaceDark = Color(0xFF1A1730)
val SurfaceLight = Color(0xFF261F47)

val NeonCyan = Color(0xFF00E5FF)
val NeonPurple = Color(0xFFB388FF)
val NeonPink = Color(0xFFFF4D8D)
val NeonGold = Color(0xFFFFD54F)
val NeonGreen = Color(0xFF69F0AE)
val NeonOrange = Color(0xFFFF6D00)
val DangerRed = Color(0xFFFF3B5C)

/** Easiest level color (level 1). */
val LevelEasyColor = Color(0xFF69F0AE)

/** Hardest level color (level 10). */
val LevelHardColor = Color(0xFFFF3B5C)
