package com.challenge.videorank

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.challenge.videorank.ui.VideoChallengeApp
import com.challenge.videorank.ui.theme.VideoChallengeTheme
import com.challenge.videorank.viewmodel.GameViewModel
import com.challenge.videorank.viewmodel.GameViewModelFactory

class MainActivity : ComponentActivity() {

    private val viewModel: GameViewModel by viewModels {
        GameViewModelFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VideoChallengeTheme {
                VideoChallengeApp(viewModel = viewModel)
            }
        }
    }
}
