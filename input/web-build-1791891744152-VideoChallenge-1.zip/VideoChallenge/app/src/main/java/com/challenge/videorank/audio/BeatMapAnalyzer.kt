package com.challenge.videorank.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A precomputed rhythm map for one specific video's real audio track, built
 * with the same family of technique real music-analysis tools use (the one
 * behind librosa's `beat_track`, among others): spectral onset detection
 * plus a dynamic-programming beat tracker, not a simple volume-spike guess.
 *
 * [beatsMs] is the resulting beat sequence — no artificial subdivisions
 * layered on top of it, no difficulty knob baked into the map itself. How
 * dense it is, is entirely up to the song: a fast track naturally produces
 * closely-spaced beats, a slow one naturally produces widely-spaced ones. A
 * moment that's actually silent in the track produces no beat at all there.
 */
data class BeatMap(
    val durationMs: Long,
    val beatsMs: LongArray,
    val intensityCurve: FloatArray,
    val intensityHopMs: Long
) {
    fun intensityAt(positionMs: Long): Float {
        if (intensityCurve.isEmpty()) return 0f
        val idx = (positionMs / intensityHopMs).toInt().coerceIn(0, intensityCurve.size - 1)
        return intensityCurve[idx]
    }
}

/** The next [count] timestamps in this (sorted) grid at or after [positionMs]. */
fun LongArray.from(positionMs: Long, count: Int): List<Long> {
    if (isEmpty()) return emptyList()
    val startIdx = binarySearch(positionMs).let { if (it < 0) -(it + 1) else it }
    if (startIdx >= size) return emptyList()
    return (startIdx until min(size, startIdx + count)).map { this[it] }
}

/** The timestamp in this (sorted) grid at or immediately before [positionMs], if any. */
fun LongArray.atOrBefore(positionMs: Long): Long? {
    if (isEmpty()) return null
    var idx = binarySearch(positionMs)
    if (idx < 0) idx = -(idx + 1) - 1
    return if (idx in indices) this[idx] else null
}

/**
 * Decodes a video's real audio track once and runs a proper beat-tracking
 * pipeline on it: a spectral onset-strength signal (not just raw volume), a
 * tempo estimate biased away from the classic "double or half speed" octave
 * mistake, and a dynamic-programming pass that places each beat where the
 * real audio evidence is strongest *and* keeps the overall pacing coherent —
 * the same balance a human tapping along to a song finds. Results are
 * cached to disk, so the decode only happens the first time.
 */
object BeatMapAnalyzer {

    /** FFT window: ~46ms at 44.1kHz. Must be a power of two. */
    private const val WINDOW_SAMPLES = 2048

    /** 50% overlap between windows — fine enough resolution without doubling the FFT cost. */
    private const val HOP_SAMPLES = 1024

    private const val MIN_BPM = 60f
    private const val MAX_BPM = 200f

    /** Tempo estimates are pulled toward this value on a log scale, to break octave ties. */
    private const val TEMPO_PRIOR_BPM = 120f

    /** How forgiving that pull is — wide enough to still land on a genuine 70 or 180 BPM track. */
    private const val TEMPO_PRIOR_SIGMA = 0.55f

    /**
     * How strongly the beat tracker favors a steady tempo over chasing every
     * flicker in the onset signal. Low enough to still follow a track that
     * genuinely speeds up or slows down.
     */
    private const val TEMPO_RIGIDITY = 240f

    /** How far around a candidate beat to look when deciding if it lands in silence. */
    private const val SILENCE_CHECK_WINDOW_MS = 70L

    private val memoryCache = mutableMapOf<String, BeatMap?>()

    suspend fun analyze(context: Context, uri: Uri, cacheKey: String): BeatMap? =
        withContext(Dispatchers.Default) {
            if (memoryCache.containsKey(cacheKey)) return@withContext memoryCache[cacheKey]

            loadFromDisk(context, cacheKey)?.let {
                memoryCache[cacheKey] = it
                return@withContext it
            }

            val map = try {
                decodeAndAnalyze(context, uri)
            } catch (e: Exception) {
                Log.w("BeatMapAnalyzer", "Could not analyze audio for $uri, falling back", e)
                null
            }
            memoryCache[cacheKey] = map
            if (map != null) saveToDisk(context, cacheKey, map)
            map
        }

    private fun decodeAndAnalyze(context: Context, uri: Uri): BeatMap? {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)

        var audioTrack = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                audioTrack = i
                format = f
                break
            }
        }
        if (audioTrack < 0 || format == null) {
            extractor.release()
            return null
        }
        extractor.selectTrack(audioTrack)

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE))
            format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
        val channelCount = (if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT))
            format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1).coerceAtLeast(1)

        // ms per analysis hop, derived from this track's own sample rate so the
        // FFT window always represents the same real-world time span.
        val hopMs = max(1L, HOP_SAMPLES * 1000L / sampleRate)

        val hann = FloatArray(WINDOW_SAMPLES) { i ->
            (0.5 - 0.5 * cos(2.0 * PI * i / (WINDOW_SAMPLES - 1))).toFloat()
        }
        val ring = FloatArray(WINDOW_SAMPLES)
        var writeIdx = 0
        var filled = 0
        var sinceLastFrame = 0

        val fftRe = FloatArray(WINDOW_SAMPLES)
        val fftIm = FloatArray(WINDOW_SAMPLES)
        val bins = WINDOW_SAMPLES / 2
        val prevMag = FloatArray(bins)

        val intensityList = ArrayList<Float>(4096)
        // Spectral-flux onset strength: how much the spectrum's energy jumped
        // since the previous analysis frame, summed across frequency bins.
        // This is what the tempo estimate and the beat sequence are built
        // from — far more sensitive to real musical onsets (a kick, a strum,
        // a vocal hit) than a plain volume measurement, which misses anything
        // that isn't simply "loud".
        val fluxList = ArrayList<Float>(4096)

        val bufferInfo = MediaCodec.BufferInfo()
        var sawInputEof = false
        var sawOutputEof = false
        var totalDurationUs = 0L

        // Cap analysis so a very long import still finishes quickly; most
        // personal-clip challenges are well under this anyway.
        val maxDurationUs = 6L * 60L * 1_000_000L

        fun processFrame() {
            // Read the ring buffer out in chronological order (oldest sample
            // first) and apply the analysis window.
            for (i in 0 until WINDOW_SAMPLES) {
                val srcIdx = (writeIdx + i) % WINDOW_SAMPLES
                fftRe[i] = ring[srcIdx] * hann[i]
                fftIm[i] = 0f
            }
            fft(fftRe, fftIm)

            var flux = 0f
            var energy = 0f
            for (k in 1 until bins) {
                val mag = sqrt(fftRe[k] * fftRe[k] + fftIm[k] * fftIm[k])
                val diff = mag - prevMag[k]
                if (diff > 0f) flux += diff
                energy += mag
                prevMag[k] = mag
            }
            intensityList.add(energy / bins)
            fluxList.add(flux / bins)
        }

        while (!sawOutputEof) {
            if (!sawInputEof) {
                val inIndex = codec.dequeueInputBuffer(10_000)
                if (inIndex >= 0) {
                    val inBuffer = codec.getInputBuffer(inIndex)!!
                    val sampleSize = extractor.readSampleData(inBuffer, 0)
                    if (sampleSize < 0 || extractor.sampleTime > maxDurationUs) {
                        codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        sawInputEof = true
                    } else {
                        val presentationTimeUs = extractor.sampleTime
                        totalDurationUs = max(totalDurationUs, presentationTimeUs)
                        codec.queueInputBuffer(inIndex, 0, sampleSize, presentationTimeUs, 0)
                        extractor.advance()
                    }
                }
            }

            val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
            if (outIndex >= 0) {
                val outBuffer = codec.getOutputBuffer(outIndex)
                if (outBuffer != null && bufferInfo.size > 0) {
                    outBuffer.position(bufferInfo.offset)
                    outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                    val totalShorts = bufferInfo.size / 2

                    var consumed = 0
                    while (consumed + channelCount <= totalShorts && outBuffer.remaining() >= channelCount * 2) {
                        var frameSum = 0
                        for (c in 0 until channelCount) {
                            val lo = outBuffer.get().toInt() and 0xFF
                            val hi = outBuffer.get().toInt()
                            frameSum += (hi shl 8) or lo
                        }
                        consumed += channelCount
                        val mono = (frameSum / channelCount) / 32768f

                        ring[writeIdx] = mono
                        writeIdx = (writeIdx + 1) % WINDOW_SAMPLES
                        if (filled < WINDOW_SAMPLES) filled++
                        sinceLastFrame++

                        if (filled >= WINDOW_SAMPLES && sinceLastFrame >= HOP_SAMPLES) {
                            sinceLastFrame = 0
                            processFrame()
                        }
                    }
                }
                codec.releaseOutputBuffer(outIndex, false)
                if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                    sawOutputEof = true
                }
            }
        }

        try {
            codec.stop()
        } catch (e: Exception) { /* already stopped */ }
        codec.release()
        extractor.release()

        if (fluxList.isEmpty()) return null

        // Normalize both curves against this track's own peak, so every
        // downstream threshold is relative to this specific clip rather than
        // an absolute volume that would only suit some recordings.
        val intensityArray = normalize(intensityList)
        val fluxArray = normalize(fluxList)

        val periodMs = estimateGlobalPeriod(fluxArray, hopMs)
        val beats = trackBeatsDp(fluxArray, periodMs, hopMs)

        // Drop any beat that lands where the track is actually quiet — a
        // real pause, a silent intro, the gap between songs in a mashup —
        // instead of letting the tracker place one there anyway. The
        // threshold is relative to this specific track's own average
        // loudness, so it adapts instead of using one fixed volume for every
        // video.
        val silenceThreshold = silenceThresholdFor(intensityArray)
        val audibleBeats = beats.filter { isAudibleAt(intensityArray, hopMs, it, silenceThreshold) }

        return BeatMap(
            durationMs = totalDurationUs / 1000L,
            beatsMs = audibleBeats.toLongArray(),
            intensityCurve = intensityArray,
            intensityHopMs = hopMs
        )
    }

    private fun normalize(values: List<Float>): FloatArray {
        var peak = 0f
        for (v in values) if (v > peak) peak = v
        if (peak <= 0f) return FloatArray(values.size)
        return FloatArray(values.size) { (values[it] / peak).coerceIn(0f, 1f) }
    }

    /**
     * Global tempo estimate via autocorrelation of the onset-strength signal
     * across the *whole* track, with one crucial addition over a plain
     * peak-pick: a log-normal prior centered on a common musical tempo. Raw
     * autocorrelation on real music very often scores a candidate tempo's
     * exact double or half just as high as the true one (a backbeat lines up
     * with itself either way) — that octave confusion is the single most
     * common failure mode of naive beat detectors, and it's exactly what
     * made the old version "sometimes right, sometimes wrong". Weighting the
     * score toward a plausible range breaks that tie correctly almost all of
     * the time.
     */
    private fun estimateGlobalPeriod(flux: FloatArray, hopMs: Long): Long {
        val minPeriodMs = 60_000f / MAX_BPM
        val maxPeriodMs = 60_000f / MIN_BPM
        val minLag = max(1, (minPeriodMs / hopMs).toInt())
        val maxLag = (maxPeriodMs / hopMs).toInt().coerceAtLeast(minLag + 1)
        if (flux.size < maxLag * 2) return (60_000f / TEMPO_PRIOR_BPM).toLong()

        var bestLag = -1
        var bestScore = -1f
        for (lag in minLag..maxLag) {
            var sum = 0f
            var count = 0
            var i = 0
            while (i < flux.size - lag) {
                sum += flux[i] * flux[i + lag]
                count++
                i++
            }
            if (count == 0) continue
            val raw = sum / count
            val bpm = 60_000f / (lag * hopMs)
            val logRatio = ln((bpm / TEMPO_PRIOR_BPM).toDouble()).toFloat()
            val prior = exp((-0.5 * (logRatio / TEMPO_PRIOR_SIGMA) * (logRatio / TEMPO_PRIOR_SIGMA)).toDouble()).toFloat()
            val score = raw * prior
            if (score > bestScore) {
                bestScore = score
                bestLag = lag
            }
        }
        return if (bestLag > 0) bestLag * hopMs else (60_000f / TEMPO_PRIOR_BPM).toLong()
    }

    /**
     * Places the actual beats with a dynamic-programming pass over the whole
     * track (the same idea behind the standard Ellis beat tracker): for every
     * instant, it looks back across a window of plausible beat intervals
     * around [periodMs] and keeps whichever predecessor gives the best
     * trade-off between "real onset evidence right here" and "a sensible gap
     * since the last beat". That lets the result snap to what's actually
     * playing — unlike a rigid, pre-computed grid — while staying musically
     * coherent instead of chasing every small bump in the signal.
     */
    private fun trackBeatsDp(flux: FloatArray, periodMs: Long, hopMs: Long): List<Long> {
        val n = flux.size
        if (n == 0) return emptyList()

        val periodIdx = (periodMs.toFloat() / hopMs).coerceAtLeast(1f)
        val minLag = max(1, (periodIdx * 0.5f).toInt())
        val maxLag = (periodIdx * 2f).toInt().coerceAtLeast(minLag + 1)

        val cumScore = FloatArray(n)
        val backlink = IntArray(n) { -1 }

        for (i in 0 until n) {
            var best = flux[i]
            var bestJ = -1
            val jFrom = max(0, i - maxLag)
            val jTo = i - minLag
            var j = jFrom
            while (j <= jTo) {
                val delta = (i - j).toFloat()
                val logRatio = ln((delta / periodIdx).toDouble()).toFloat()
                val transitionCost = TEMPO_RIGIDITY * logRatio * logRatio
                val score = cumScore[j] - transitionCost + flux[i]
                if (score > best) {
                    best = score
                    bestJ = j
                }
                j++
            }
            cumScore[i] = best
            backlink[i] = bestJ
        }

        val beats = ArrayList<Long>()
        var cur = n - 1
        while (cur >= 0) {
            beats.add(cur * hopMs)
            cur = backlink[cur]
        }
        beats.reverse()
        return beats
    }

    /** Standard iterative radix-2 Cooley-Tukey FFT, in place. [re].size must be a power of two. */
    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j or bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wReal = cos(ang).toFloat()
            val wImag = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var curReal = 1f
                var curImag = 0f
                val half = len / 2
                for (k in 0 until half) {
                    val uRe = re[i + k]
                    val uIm = im[i + k]
                    val vRe = re[i + k + half] * curReal - im[i + k + half] * curImag
                    val vIm = re[i + k + half] * curImag + im[i + k + half] * curReal
                    re[i + k] = uRe + vRe
                    im[i + k] = uIm + vIm
                    re[i + k + half] = uRe - vRe
                    im[i + k + half] = uIm - vIm
                    val nextReal = curReal * wReal - curImag * wImag
                    val nextImag = curReal * wImag + curImag * wReal
                    curReal = nextReal
                    curImag = nextImag
                }
                i += len
            }
            len = len shl 1
        }
    }

    /**
     * A per-track loudness floor below which a moment counts as "silence" for
     * beat purposes: a fraction of that track's own average level (so a
     * quiet acoustic clip and a loud, compressed one are each judged against
     * themselves), with a small absolute floor so a genuinely silent track
     * doesn't produce a near-zero threshold that lets noise floor through.
     */
    private fun silenceThresholdFor(intensity: FloatArray): Float {
        if (intensity.isEmpty()) return 0.02f
        var sum = 0f
        for (v in intensity) sum += v
        val average = sum / intensity.size
        return (average * 0.24f).coerceAtLeast(0.015f)
    }

    private fun isAudibleAt(intensity: FloatArray, hopMs: Long, atMs: Long, threshold: Float): Boolean {
        if (intensity.isEmpty()) return false
        val centerIdx = (atMs / hopMs).toInt().coerceIn(0, intensity.size - 1)
        val windowHops = max(1, (SILENCE_CHECK_WINDOW_MS / hopMs).toInt())
        val from = (centerIdx - windowHops).coerceAtLeast(0)
        val to = (centerIdx + windowHops).coerceAtMost(intensity.size - 1)
        var sum = 0f
        for (i in from..to) sum += intensity[i]
        val localAverage = sum / (to - from + 1)
        return localAverage >= threshold
    }

    private fun cacheFile(context: Context, cacheKey: String): File =
        File(context.cacheDir, "beatmaps").apply { mkdirs() }.resolve("$cacheKey.json")

    private fun loadFromDisk(context: Context, cacheKey: String): BeatMap? = try {
        val file = cacheFile(context, cacheKey)
        if (!file.exists()) null else {
            val json = JSONObject(file.readText())
            val beatsJson = json.getJSONArray("beats")
            val beats = LongArray(beatsJson.length()) { beatsJson.getLong(it) }
            val intensityJson = json.getJSONArray("intensity")
            val intensity = FloatArray(intensityJson.length()) { intensityJson.getDouble(it).toFloat() }
            BeatMap(
                durationMs = json.getLong("durationMs"),
                beatsMs = beats,
                intensityCurve = intensity,
                intensityHopMs = json.getLong("intensityHopMs")
            )
        }
    } catch (e: Exception) {
        null
    }

    private fun saveToDisk(context: Context, cacheKey: String, map: BeatMap) {
        try {
            val json = JSONObject()
            json.put("durationMs", map.durationMs)
            json.put("beats", JSONArray(map.beatsMs.toList()))
            json.put("intensity", JSONArray(map.intensityCurve.toList()))
            json.put("intensityHopMs", map.intensityHopMs)
            cacheFile(context, cacheKey).writeText(json.toString())
        } catch (e: Exception) {
            // Cache is an optimization; losing it just means re-analyzing next time.
        }
    }

    fun cacheKeyFor(uri: Uri): String {
        val digest = MessageDigest.getInstance("MD5").digest(uri.toString().toByteArray())
        return digest.joinToString("") { "%02x".format(it) } + "-v5"
    }
}
