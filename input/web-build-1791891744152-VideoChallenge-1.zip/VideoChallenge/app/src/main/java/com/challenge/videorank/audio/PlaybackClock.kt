package com.challenge.videorank.audio

import android.os.SystemClock

/**
 * Tracks "where are we in this video's audio, right now" so the beat bar can
 * place notes against the real timeline instead of a live-guessed one. The
 * player polls the real position every so often via [sync]; between polls,
 * [estimatedPositionMs] extrapolates forward from the last known point using
 * the device clock, so the animation stays smooth at 60fps even though the
 * underlying position check only happens a few times a second.
 */
class PlaybackClock {
    @Volatile private var lastKnownPositionMs: Long = 0L
    @Volatile private var lastSampleAt: Long = SystemClock.elapsedRealtime()

    fun sync(positionMs: Long) {
        lastKnownPositionMs = positionMs
        lastSampleAt = SystemClock.elapsedRealtime()
    }

    fun estimatedPositionMs(): Long =
        lastKnownPositionMs + (SystemClock.elapsedRealtime() - lastSampleAt)
}
