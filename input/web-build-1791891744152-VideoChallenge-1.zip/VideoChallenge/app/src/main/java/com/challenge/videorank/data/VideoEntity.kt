package com.challenge.videorank.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One imported video. [level] is the difficulty slot (1 = easiest ... 10 = hardest)
 * that the person manually assigned it to in the Level Editor. `null` means the
 * video has been imported but not placed into the 10-level challenge yet.
 */
@Entity(tableName = "videos")
data class VideoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val displayName: String,
    val durationMs: Long,
    val level: Int? = null,
    val createdAt: Long = System.currentTimeMillis()
)
