package com.challenge.videorank.viewmodel

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.challenge.videorank.audio.BeatMap
import com.challenge.videorank.audio.BeatMapAnalyzer
import com.challenge.videorank.data.AppDatabase
import com.challenge.videorank.data.VideoEntity
import com.challenge.videorank.util.VideoUtils
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Total number of difficulty levels in a challenge run. */
const val TOTAL_LEVELS = 10

/**
 * Drives the app: importing videos and letting the person manually place each
 * one into a difficulty level (1 = easiest ... 10 = hardest). Playing the game
 * (GameScreen) just reads back whichever video sits at the current level.
 */
class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getInstance(application).videoDao()

    val videos: StateFlow<List<VideoEntity>> = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val thumbnailCache = mutableMapOf<String, Bitmap?>()
    private val framesCache = mutableMapOf<String, List<Bitmap>>()
    private val beatMapJobs = mutableMapOf<String, Deferred<BeatMap?>>()

    fun importVideos(uris: List<Uri>) {
        val context = getApplication<Application>()
        viewModelScope.launch {
            for (uri in uris) {
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: SecurityException) {
                    // Some providers don't support persistable grants; the Uri may still
                    // work for the current session, so we keep going instead of failing.
                }
                val uriString = uri.toString()
                if (dao.countByUri(uriString) > 0) continue
                val meta = VideoUtils.readMeta(context, uri)
                dao.insert(
                    VideoEntity(
                        uri = uriString,
                        displayName = meta.displayName,
                        durationMs = meta.durationMs
                    )
                )
            }
        }
    }

    suspend fun thumbnailFor(video: VideoEntity): Bitmap? {
        thumbnailCache[video.uri]?.let { return it }
        val context = getApplication<Application>()
        val bmp = VideoUtils.extractThumbnail(context, Uri.parse(video.uri))
        thumbnailCache[video.uri] = bmp
        return bmp
    }

    /** A handful of stills spread across [video], used for the GTA-style loading screen. */
    suspend fun framesFor(video: VideoEntity, count: Int = 5): List<Bitmap> {
        framesCache[video.uri]?.let { return it }
        val context = getApplication<Application>()
        val frames = VideoUtils.extractFrames(context, Uri.parse(video.uri), count)
        if (frames.isNotEmpty()) framesCache[video.uri] = frames
        return frames
    }

    /** Places [video] at [level], bumping whatever video previously held that level to unassigned. */
    fun assignVideoToLevel(video: VideoEntity, level: Int) {
        viewModelScope.launch {
            val current = videos.value
            current.firstOrNull { it.level == level && it.id != video.id }?.let { occupant ->
                dao.update(occupant.copy(level = null))
            }
            dao.update(video.copy(level = level))
        }
    }

    fun unassignLevel(level: Int) {
        viewModelScope.launch {
            videos.value.firstOrNull { it.level == level }?.let {
                dao.update(it.copy(level = null))
            }
        }
    }

    /**
     * The decode-and-analyze job for [video]'s audio, started at most once:
     * if it's already running (or done) for this video, every caller just
     * awaits the same result instead of kicking off a second decode.
     */
    private fun beatMapJob(video: VideoEntity): Deferred<BeatMap?> =
        beatMapJobs.getOrPut(video.uri) {
            viewModelScope.async(Dispatchers.Default) {
                val context = getApplication<Application>()
                val key = BeatMapAnalyzer.cacheKeyFor(Uri.parse(video.uri))
                BeatMapAnalyzer.analyze(context, Uri.parse(video.uri), key)
            }
        }

    /**
     * Starts analyzing [video]'s real audio right away, without waiting for
     * the result — meant to be called as soon as that level's loading screen
     * appears, so the decode runs in the background while the player is busy
     * reading the loading tip, and is normally already finished by the time
     * the video actually starts (instead of starting the decode only once
     * playback begins, which is what caused the beat bar to visibly "jump"
     * from a placeholder pulse to the real one a few seconds in).
     */
    fun prefetchBeatMap(video: VideoEntity) {
        beatMapJob(video)
    }

    /**
     * The real rhythm map for [video]'s actual audio track — awaits whatever
     * analysis is already running for it (started by [prefetchBeatMap], or
     * started right now if nothing was prefetched), and is itself cached (in
     * memory and on disk by [BeatMapAnalyzer]) so a replay is instant.
     */
    suspend fun beatMapFor(video: VideoEntity): BeatMap? = beatMapJob(video).await()

    fun videoForLevel(level: Int): VideoEntity? = videos.value.firstOrNull { it.level == level }

    fun configuredLevelsCount(): Int = videos.value.count { it.level != null }
}

class GameViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return GameViewModel(application) as T
    }
}
