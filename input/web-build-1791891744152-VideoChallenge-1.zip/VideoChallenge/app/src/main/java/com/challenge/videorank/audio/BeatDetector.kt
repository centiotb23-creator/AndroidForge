package com.challenge.videorank.audio

import android.media.audiofx.Visualizer
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.sqrt

/**
 * Listens to the real audio of whatever is currently playing in [audioSessionId]
 * (the level's video) and turns it into two things the beat bar can react to:
 *
 * - [liveEnergy]: a smoothed 0..1 loudness value, for a subtle continuous pulse.
 * - [beatEvents]: a timestamp (from [SystemClock.elapsedRealtime]) each time a
 *   real onset is detected in the music.
 *
 * Beat detection uses the classic "sound energy" approach: it keeps a short
 * rolling history (~1s) of the track's instantaneous energy, and fires a beat
 * when the *current* energy spikes above the *local* average by a margin that
 * itself adapts to how much the energy has been varying recently — a loud,
 * driving track needs a bigger relative spike to count than a quiet, steady
 * one. That makes the detector react to the actual music playing instead of
 * firing at some fixed rate.
 *
 * Visualizer isn't available on every device/session, so [start] fails silently:
 * the beat bar just falls back to a steady decorative pulse instead of crashing.
 */
class BeatDetector(private val audioSessionId: Int) {

    private var visualizer: Visualizer? = null

    private val _liveEnergy = MutableStateFlow(0f)
    val liveEnergy: StateFlow<Float> = _liveEnergy

    private val _beatEvents = MutableSharedFlow<Long>(extraBufferCapacity = 8)
    val beatEvents: SharedFlow<Long> = _beatEvents

    // Rolling history of instantaneous energy, used to compute a local average
    // and variance so the trigger threshold adapts to the track itself rather
    // than to a single fixed multiplier.
    private val historySize = 42 // roughly the last ~1s at this capture rate
    private val energyHistory = FloatArray(historySize)
    private var historyFilled = 0
    private var historyIndex = 0

    private var lastBeatAt = 0L

    /**
     * Minimum gap between detected beats. Real songs rarely go faster than
     * ~230 BPM, so this both avoids firing a burst of events on one loud hit
     * and keeps noisy false positives from making the tempo look faster than
     * the music actually is.
     */
    private val minBeatGapMs = 230L

    fun start() {
        if (audioSessionId == 0) return
        try {
            val visualizer = Visualizer(audioSessionId)
            val maxCapture = Visualizer.getCaptureSizeRange().getOrNull(1) ?: 1024
            visualizer.captureSize = maxCapture.coerceAtMost(1024)
            visualizer.setDataCaptureListener(
                object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(
                        v: Visualizer?,
                        waveform: ByteArray?,
                        samplingRate: Int
                    ) {
                        waveform?.let(::onWaveform)
                    }

                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                        // Not used: the raw waveform's energy already drives detection and
                        // is much cheaper per frame than decoding FFT bins.
                    }
                },
                // A moderate capture rate: fast enough to follow real rhythm changes,
                // but the device maximum is noisy enough to manufacture false onsets,
                // which is what made the bar feel faster than the actual music.
                (Visualizer.getMaxCaptureRate() / 2).coerceAtLeast(10000),
                true,
                false
            )
            visualizer.enabled = true
            this.visualizer = visualizer
        } catch (e: Exception) {
            // Some devices/sessions refuse Visualizer; the beat bar degrades gracefully.
            visualizer = null
        }
    }

    private fun onWaveform(waveform: ByteArray) {
        var sumSq = 0.0
        for (b in waveform) {
            val centered = (b.toInt() and 0xFF) - 128
            sumSq += (centered * centered).toDouble()
        }
        val instantEnergy = (sumSq / waveform.size).toFloat() // roughly 0..16384
        val normalized = (sqrt(instantEnergy.toDouble()) / 128.0).toFloat().coerceIn(0f, 1f)
        _liveEnergy.value = _liveEnergy.value * 0.7f + normalized * 0.3f

        energyHistory[historyIndex] = instantEnergy
        historyIndex = (historyIndex + 1) % historySize
        if (historyFilled < historySize) historyFilled++

        // Need a bit of history before the local average/variance mean anything.
        if (historyFilled >= historySize / 2) {
            var sum = 0f
            for (i in 0 until historyFilled) sum += energyHistory[i]
            val average = sum / historyFilled

            var variance = 0f
            for (i in 0 until historyFilled) {
                val d = energyHistory[i] - average
                variance += d * d
            }
            variance /= historyFilled

            // A steadier track (low variance) needs a smaller relative spike to
            // register as a beat; a wildly dynamic track needs a bigger one.
            // This is what keeps the detector honest across very different songs
            // instead of either missing everything or firing constantly.
            val sensitivity = (-0.0025714f * variance + 1.5142857f).coerceIn(1.05f, 2.4f)

            val now = SystemClock.elapsedRealtime()
            val isBeat = average > 4f && instantEnergy > average * sensitivity
            if (isBeat && now - lastBeatAt > minBeatGapMs) {
                lastBeatAt = now
                _beatEvents.tryEmit(now)
            }
        }
    }

    fun stop() {
        try {
            visualizer?.enabled = false
            visualizer?.release()
        } catch (e: Exception) {
            // Already released or never started; nothing to clean up.
        }
        visualizer = null
    }
}
