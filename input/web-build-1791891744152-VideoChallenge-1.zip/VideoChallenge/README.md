# Video Challenge 🎮

App Android (Kotlin + Jetpack Compose) para importar los vídeos que ya tienes
descargados en el móvil y montar con ellos un reto de **10 niveles**, del más
fácil al más difícil, como si fuera un videojuego.

## Cómo funciona

1. **Importar vídeos**: pulsa "Importar vídeos" y elige, con el selector de
   archivos del propio Android, los vídeos que tengas descargados (no se piden
   permisos de almacenamiento: se usa el selector de documentos del sistema,
   que da acceso directo y persistente solo a los archivos que elijas).
2. **Editar niveles** 🎯: eliges manualmente qué vídeo va en cada uno de los
   10 niveles (nivel 1 = el más fácil, nivel 10 = el más difícil). Tocas un
   nivel, eliges el vídeo de tu lista y queda asignado. Puedes cambiarlo
   cuando quieras.
3. **Jugar** ▶️ (se activa solo cuando los 10 niveles están configurados):
   - Se reproduce el vídeo del nivel 1 a pantalla completa.
   - En cuanto el vídeo termina, se pasa automáticamente al nivel 2, y así
     sucesivamente hasta el nivel 10.
   - Mientras ves un vídeo hay un botón **"RENDIRSE"**. Si lo pulsas, pierdes
     la partida al instante y se muestra el nivel en el que te quedaste.
   - Si completas el vídeo del nivel 10, ganas el reto y se muestra una
     pantalla de victoria.
   - Desde la pantalla de fin de partida (victoria o derrota) puedes
     reintentar desde el nivel 1 o volver al menú.

## Elementos de videojuego incluidos

- Indicador superior "NIVEL X / 10" con puntitos de progreso que se van
  iluminando con el color del nivel actual (verde → rojo según la dificultad).
- Botón "RENDIRSE" siempre visible mientras juegas.
- Pantalla de "HAS FALLADO" al rendirte, con el nivel alcanzado.
- Pantalla de "¡RETO COMPLETADO!" con animación de trofeo pulsante al acabar
  los 10 niveles.
- Paleta neón oscura (cian, morado, rosa, dorado) con degradados, pensada
  para sentirse como una interfaz de juego y no como un gestor de archivos.
- Editor de niveles con miniaturas generadas directamente de cada vídeo y
  un selector visual para asignar cada vídeo a su nivel.

## Abrir el proyecto

1. Instala **Android Studio** (versión Koala 2024.1 o posterior).
2. `Open` → selecciona la carpeta `VideoChallenge` (la que contiene este
   `README.md`).
3. Deja que Android Studio sincronice Gradle. Si te pregunta por el
   "Gradle Wrapper" (falta el `.jar` del wrapper, que no se incluye aquí),
   acepta que Android Studio lo regenere o use su propio Gradle incluido —
   es automático, no hace falta hacer nada manualmente.
4. Conecta un móvil (Android 8.0 / API 26 o superior) con la depuración USB
   activada, o usa un emulador, y pulsa ▶️ Run.

No se necesita ninguna cuenta ni servidor: todo (vídeos importados y a qué
nivel pertenece cada uno) se guarda localmente en el propio dispositivo con
una base de datos Room.

## Estructura del proyecto

```
app/src/main/java/com/challenge/videorank/
├── MainActivity.kt
├── data/              → Entidad Room (vídeo + nivel asignado), DAO, base de datos
├── viewmodel/          → Importar vídeos, asignar/quitar niveles, miniaturas
├── util/                → Lectura de metadatos y miniaturas de vídeo
└── ui/
    ├── theme/           → Colores, tipografía, tema oscuro neón
    ├── components/      → Color por nivel (verde→rojo), utilidades de UI
    ├── screens/
    │   ├── HomeScreen.kt       → Menú principal
    │   ├── LevelEditorScreen.kt → Asignar un vídeo a cada uno de los 10 niveles
    │   └── GameScreen.kt        → Reproduce los niveles en orden, botón Rendirse
    └── VideoChallengeApp.kt → Navegación
```

## Posibles mejoras futuras

- Pausar/reanudar un vídeo en mitad del nivel.
- Vista previa del vídeo al elegirlo en el editor de niveles.
- Confeti o partículas al completar un nivel, no solo al ganar el reto.
- Varios "retos" guardados con sus propios 10 niveles, para no tener que
  reconfigurar todo cada vez.
- Marcador del mejor nivel alcanzado.

---

Este proyecto se generó como código fuente completo de Android Studio; no se
ha podido compilar un APK dentro de este entorno (no incluye el SDK de
Android), pero el código está escrito y revisado cuidadosamente para
compilar tal cual al abrirlo en Android Studio.
