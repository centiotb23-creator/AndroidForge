package com.challenge.videorank.ui.components

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.challenge.videorank.audio.BeatMap
import com.challenge.videorank.audio.PlaybackClock
import kotlin.math.abs
import kotlin.math.sin

/** Where the fixed "hit circle" sits, as a fraction of the bar's width — dead center. */
private const val HIT_X_FRACTION = 0.5f

/** How far past the hit point a note keeps drifting (and fading) before disappearing. */
private const val EXIT_MS = 260L

/**
 * A rhythm-game-style bar driven by a real, precomputed analysis of the
 * video's own audio ([beatMap]) rather than a live guess: notes approach the
 * fixed hit circle in the middle exactly when that video's real onsets land,
 * so the distance between notes and how fast they close in on the circle
 * both follow the actual song — tight and quick through a busy section,
 * loose and slow through a quiet one — without any artificial smoothing
 * flattening that out.
 *
 * [level] raises the difficulty on top of that: higher levels show more
 * notes approaching at once and give less lead time to react to each one.
 *
 * Falls back to a calm decorative pulse if [beatMap] is null (analysis
 * failed, still running, or the clip has no usable audio track) instead of
 * breaking or looking frozen.
 */
@Composable
fun BeatBar(
    beatMap: BeatMap?,
    playbackClock: PlaybackClock,
    level: Int,
    modifier: Modifier = Modifier
) {
    var nowElapsed by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var hitFlash by remember { mutableFloatStateOf(0f) }
    var lastFlashedOnset by remember { mutableLongStateOf(-1L) }
    val fallback = remember { FallbackRhythm() }

    // Harder levels: more notes approaching at once, and a shorter runway to
    // react to each (the window during which a note is visible before it hits).
    val visibleNotes = (2 + level / 2).coerceIn(2, 6)
    val leadMs = (1700L - level * 95L).coerceIn(650L, 1700L)

    LaunchedEffect(beatMap) {
        while (true) {
            withFrameMillis { }
            nowElapsed = SystemClock.elapsedRealtime()

            if (beatMap == null) {
                fallback.tick(nowElapsed)
            }

            val positionMs = if (beatMap != null) {
                playbackClock.estimatedPositionMs().coerceIn(0L, beatMap.durationMs.coerceAtLeast(1L))
            } else {
                fallback.positionMs
            }

            val justHit = beatMap?.onsetAtOrBefore(positionMs) ?: fallback.onsetAtOrBefore(positionMs)
            if (justHit != null && justHit != lastFlashedOnset && positionMs - justHit < 120L) {
                lastFlashedOnset = justHit
                hitFlash = 1f
            }
            hitFlash = (hitFlash - 0.05f).coerceAtLeast(0f)
        }
    }

    val idlePulse = 0.5f + 0.5f * sin(nowElapsed / 260f)

    Canvas(modifier = modifier.fillMaxSize()) {
        val hitX = size.width * HIT_X_FRACTION
        val centerY = size.height / 2f

        val positionMs = if (beatMap != null) {
            playbackClock.estimatedPositionMs().coerceIn(0L, beatMap.durationMs.coerceAtLeast(1L))
        } else {
            fallback.positionMs
        }

        // Background waveform: a real trace of this track's own loudness,
        // centered on "now" — the left half is the recent past, the right
        // half previews what's coming, both read straight from the analysis.
        val halfWindowMs = 2200L
        val hop = 18.dp.toPx()
        var x = 0f
        while (x <= size.width) {
            val sampleAt = positionMs - halfWindowMs + ((x / size.width) * (2 * halfWindowMs)).toLong()
            val amplitude = if (beatMap != null) {
                if (sampleAt < 0 || sampleAt > beatMap.durationMs) 0f else beatMap.intensityAt(sampleAt)
            } else {
                fallback.intensityAt(sampleAt)
            }
            val h = (amplitude.coerceIn(0f, 1f) * size.height * 0.4f).coerceAtLeast(2f)
            val distanceFromHit = abs(x - hitX) / size.width
            val alpha = (0.5f - distanceFromHit * 0.4f).coerceIn(0.12f, 0.5f)
            drawLine(
                color = Color(0xFFE056C4).copy(alpha = alpha),
                start = Offset(x, centerY - h / 2f),
                end = Offset(x, centerY + h / 2f),
                strokeWidth = (hop * 0.5f).coerceAtLeast(1f)
            )
            x += hop
        }

        // Playhead marker through the whole lane.
        drawLine(
            color = Color.White.copy(alpha = 0.18f),
            start = Offset(hitX, 0f),
            end = Offset(hitX, size.height),
            strokeWidth = 1.5.dp.toPx()
        )

        // Upcoming notes, timed against the track's real onsets: distance and
        // closing speed both follow directly from how far apart those onsets
        // really are in the music, not a fixed schedule.
        val upcoming = (beatMap?.onsetsFrom(positionMs, visibleNotes)
            ?: fallback.onsetsFrom(positionMs, visibleNotes))
        val justPassed = beatMap?.onsetAtOrBefore(positionMs) ?: fallback.onsetAtOrBefore(positionMs)

        val allNotes = buildList {
            if (justPassed != null) add(justPassed)
            addAll(upcoming)
        }.distinct()

        for (onsetAt in allNotes) {
            val timeToHit = onsetAt - positionMs
            val cx: Float
            val alpha: Float
            val radius: Float
            if (timeToHit >= 0) {
                if (timeToHit > leadMs) continue
                val progress = (1f - timeToHit.toFloat() / leadMs).coerceIn(0f, 1f)
                cx = size.width - progress * (size.width - hitX)
                alpha = (0.35f + 0.65f * progress)
                radius = 7.dp.toPx() * (0.75f + 0.25f * progress)
            } else {
                val sincePassed = -timeToHit
                if (sincePassed > EXIT_MS) continue
                val progress = (sincePassed.toFloat() / EXIT_MS).coerceIn(0f, 1f)
                cx = hitX - progress * hitX
                alpha = (1f - progress)
                radius = 7.dp.toPx() * (1f - 0.2f * progress)
            }
            drawCircle(
                color = Color(0xFF00E5FF).copy(alpha = alpha.coerceIn(0f, 1f)),
                radius = radius,
                center = Offset(cx, centerY)
            )
        }

        // The hit circle: a steady idle sway, plus a sharp flash exactly when
        // a real onset lands.
        val baseRadius = 11.dp.toPx()
        val hitRadius = baseRadius * (1f + idlePulse * 0.12f + hitFlash * 0.55f)
        val hitColor = Color(0xFFFF4D8D)

        if (hitFlash > 0.05f) {
            drawCircle(
                color = hitColor.copy(alpha = hitFlash * 0.35f),
                radius = hitRadius + 13.dp.toPx() * hitFlash,
                center = Offset(hitX, centerY)
            )
        }
        drawCircle(color = hitColor.copy(alpha = 0.9f), radius = hitRadius, center = Offset(hitX, centerY))
        drawCircle(
            color = Color.White.copy(alpha = 0.6f + hitFlash * 0.4f),
            radius = hitRadius,
            center = Offset(hitX, centerY),
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}

/**
 * Decorative-only stand-in used when a video has no usable [BeatMap] (still
 * analyzing, or no audio track at all): a gentle, clearly non-random sway so
 * the bar never looks frozen or broken while real data isn't available.
 */
private class FallbackRhythm {
    var positionMs: Long = 0L
        private set
    private var lastAt = SystemClock.elapsedRealtime()
    private val intervalMs = 700L

    fun tick(nowElapsed: Long) {
        positionMs += (nowElapsed - lastAt)
        lastAt = nowElapsed
    }

    fun intensityAt(ms: Long): Float = 0.18f + 0.1f * sin(ms / 380.0).toFloat()

    fun onsetAtOrBefore(ms: Long): Long? {
        val idx = ms / intervalMs
        return if (idx < 0) null else idx * intervalMs
    }

    fun onsetsFrom(ms: Long, count: Int): List<Long> {
        val start = (ms / intervalMs + 1) * intervalMs
        return (0 until count).map { start + it * intervalMs }
    }
}
