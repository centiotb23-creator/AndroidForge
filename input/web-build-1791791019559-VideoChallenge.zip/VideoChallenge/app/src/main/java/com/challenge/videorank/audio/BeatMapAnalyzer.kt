package com.challenge.videorank.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * A precomputed "rhythm map" for one specific video, built by actually
 * decoding its audio track once — not guessed live while playing. It holds:
 *
 * - [onsetsMs]: the real timestamps (ms into the track) where something hits
 *   — a kick, a snare, a strum, a cut. These are naturally close together in
 *   busy/fast sections and far apart in quiet/sparse ones, because they come
 *   straight from that song's own structure.
 * - [intensityCurve]: the track's loudness across its whole duration, sampled
 *   every [intensityHopMs], for drawing a real waveform instead of a decorative one.
 */
data class BeatMap(
    val durationMs: Long,
    val onsetsMs: LongArray,
    val intensityCurve: FloatArray,
    val intensityHopMs: Long
) {
    fun intensityAt(positionMs: Long): Float {
        if (intensityCurve.isEmpty()) return 0f
        val idx = (positionMs / intensityHopMs).toInt().coerceIn(0, intensityCurve.size - 1)
        return intensityCurve[idx]
    }

    /** The next [count] onsets at or after [positionMs], earliest first. */
    fun onsetsFrom(positionMs: Long, count: Int): List<Long> {
        if (onsetsMs.isEmpty()) return emptyList()
        val startIdx = onsetsMs.binarySearch(positionMs).let { if (it < 0) -(it + 1) else it }
        if (startIdx >= onsetsMs.size) return emptyList()
        return (startIdx until min(onsetsMs.size, startIdx + count)).map { onsetsMs[it] }
    }

    /** The onset at or immediately before [positionMs], if any — for the "just passed" note. */
    fun onsetAtOrBefore(positionMs: Long): Long? {
        if (onsetsMs.isEmpty()) return null
        var idx = onsetsMs.binarySearch(positionMs)
        if (idx < 0) idx = -(idx + 1) - 1
        return if (idx in onsetsMs.indices) onsetsMs[idx] else null
    }
}

/**
 * Decodes a video's real audio track once, measures its loudness over time,
 * and picks out the real onsets (beats/hits) from that — a proper offline
 * analysis instead of a live best-effort guess, so the result is specific to
 * whatever video the person assigned to that level. Results are cached to
 * disk, so the (slightly heavier) decode only happens the first time.
 */
object BeatMapAnalyzer {

    /** Analysis resolution: a window every 25ms is fine enough to catch real onsets. */
    private const val HOP_MS = 25L
    private const val MIN_ONSET_GAP_MS = 150L

    private val memoryCache = mutableMapOf<String, BeatMap?>()

    suspend fun analyze(context: Context, uri: Uri, cacheKey: String): BeatMap? =
        withContext(Dispatchers.Default) {
            if (memoryCache.containsKey(cacheKey)) return@withContext memoryCache[cacheKey]

            loadFromDisk(context, cacheKey)?.let {
                memoryCache[cacheKey] = it
                return@withContext it
            }

            val map = try {
                decodeAndAnalyze(context, uri)
            } catch (e: Exception) {
                Log.w("BeatMapAnalyzer", "Could not analyze audio for $uri, falling back", e)
                null
            }
            memoryCache[cacheKey] = map
            if (map != null) saveToDisk(context, cacheKey, map)
            map
        }

    private fun decodeAndAnalyze(context: Context, uri: Uri): BeatMap? {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)

        var audioTrack = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                audioTrack = i
                format = f
                break
            }
        }
        if (audioTrack < 0 || format == null) {
            extractor.release()
            return null
        }
        extractor.selectTrack(audioTrack)

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE))
            format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
        val channelCount = (if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT))
            format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1).coerceAtLeast(1)

        val hopSamples = max(1, (sampleRate * HOP_MS / 1000).toInt())
        var samplesInWindow = 0
        var sumSq = 0.0

        val intensityList = ArrayList<Float>(4096)
        // Onset-strength envelope: positive jumps in loudness, one value per hop.
        val fluxList = ArrayList<Float>(4096)
        var prevRms = 0f

        val bufferInfo = MediaCodec.BufferInfo()
        var sawInputEof = false
        var sawOutputEof = false
        var totalDurationUs = 0L

        // Cap analysis so a very long import still finishes quickly; most
        // personal-clip challenges are well under this anyway.
        val maxDurationUs = 6L * 60L * 1_000_000L

        while (!sawOutputEof) {
            if (!sawInputEof) {
                val inIndex = codec.dequeueInputBuffer(10_000)
                if (inIndex >= 0) {
                    val inBuffer = codec.getInputBuffer(inIndex)!!
                    val sampleSize = extractor.readSampleData(inBuffer, 0)
                    if (sampleSize < 0 || extractor.sampleTime > maxDurationUs) {
                        codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        sawInputEof = true
                    } else {
                        val presentationTimeUs = extractor.sampleTime
                        totalDurationUs = max(totalDurationUs, presentationTimeUs)
                        codec.queueInputBuffer(inIndex, 0, sampleSize, presentationTimeUs, 0)
                        extractor.advance()
                    }
                }
            }

            val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
            if (outIndex >= 0) {
                val outBuffer = codec.getOutputBuffer(outIndex)
                if (outBuffer != null && bufferInfo.size > 0) {
                    outBuffer.position(bufferInfo.offset)
                    outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                    val totalShorts = bufferInfo.size / 2

                    var consumed = 0
                    while (consumed + channelCount <= totalShorts && outBuffer.remaining() >= channelCount * 2) {
                        var frameSum = 0
                        for (c in 0 until channelCount) {
                            val lo = outBuffer.get().toInt() and 0xFF
                            val hi = outBuffer.get().toInt()
                            frameSum += (hi shl 8) or lo
                        }
                        consumed += channelCount
                        val mono = (frameSum / channelCount).toFloat()
                        sumSq += (mono * mono).toDouble()
                        samplesInWindow++
                        if (samplesInWindow >= hopSamples) {
                            val rms = (sqrt(sumSq / samplesInWindow) / 32768.0).toFloat().coerceIn(0f, 1f)
                            intensityList.add(rms)
                            fluxList.add((rms - prevRms).coerceAtLeast(0f))
                            prevRms = rms
                            sumSq = 0.0
                            samplesInWindow = 0
                        }
                    }
                }
                codec.releaseOutputBuffer(outIndex, false)
                if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                    sawOutputEof = true
                }
            }
        }

        try {
            codec.stop()
        } catch (e: Exception) { /* already stopped */ }
        codec.release()
        extractor.release()

        if (intensityList.isEmpty()) return null

        return BeatMap(
            durationMs = totalDurationUs / 1000L,
            onsetsMs = pickOnsets(fluxList, HOP_MS).toLongArray(),
            intensityCurve = intensityList.toFloatArray(),
            intensityHopMs = HOP_MS
        )
    }

    /**
     * Adaptive peak-picking over the onset-strength envelope: a window counts
     * as an onset only when it's a local maximum clearly above the *recent
     * local average* around it — not one fixed global threshold — which is
     * what lets the same pass work on a quiet acoustic clip and a loud, busy
     * one alike, and keeps tracking changes in energy as the song moves
     * between its own quiet and intense sections.
     */
    private fun pickOnsets(flux: List<Float>, hopMs: Long): List<Long> {
        if (flux.isEmpty()) return emptyList()
        val contextWindow = max(1, (900L / hopMs).toInt())
        val minGapWindows = max(1, (MIN_ONSET_GAP_MS / hopMs).toInt())

        val onsets = ArrayList<Long>()
        var lastOnsetIndex = -minGapWindows

        for (i in flux.indices) {
            val from = max(0, i - contextWindow)
            val to = min(flux.size - 1, i + contextWindow / 4)
            var sum = 0f
            for (j in from..to) sum += flux[j]
            val localAverage = sum / (to - from + 1)

            val isLocalPeak = (i == 0 || flux[i] >= flux[i - 1]) &&
                (i == flux.size - 1 || flux[i] >= flux[i + 1])

            val threshold = localAverage * 1.6f + 0.01f
            if (isLocalPeak && flux[i] > threshold && i - lastOnsetIndex >= minGapWindows) {
                onsets.add(i * hopMs)
                lastOnsetIndex = i
            }
        }
        return onsets
    }

    private fun cacheFile(context: Context, cacheKey: String): File =
        File(context.cacheDir, "beatmaps").apply { mkdirs() }.resolve("$cacheKey.json")

    private fun loadFromDisk(context: Context, cacheKey: String): BeatMap? = try {
        val file = cacheFile(context, cacheKey)
        if (!file.exists()) null else {
            val json = JSONObject(file.readText())
            val onsetsJson = json.getJSONArray("onsets")
            val onsets = LongArray(onsetsJson.length()) { onsetsJson.getLong(it) }
            val intensityJson = json.getJSONArray("intensity")
            val intensity = FloatArray(intensityJson.length()) { intensityJson.getDouble(it).toFloat() }
            BeatMap(
                durationMs = json.getLong("durationMs"),
                onsetsMs = onsets,
                intensityCurve = intensity,
                intensityHopMs = json.getLong("intensityHopMs")
            )
        }
    } catch (e: Exception) {
        null
    }

    private fun saveToDisk(context: Context, cacheKey: String, map: BeatMap) {
        try {
            val json = JSONObject()
            json.put("durationMs", map.durationMs)
            json.put("onsets", JSONArray(map.onsetsMs.toList()))
            json.put("intensity", JSONArray(map.intensityCurve.toList()))
            json.put("intensityHopMs", map.intensityHopMs)
            cacheFile(context, cacheKey).writeText(json.toString())
        } catch (e: Exception) {
            // Cache is an optimization; losing it just means re-analyzing next time.
        }
    }

    fun cacheKeyFor(uri: Uri): String {
        val digest = MessageDigest.getInstance("MD5").digest(uri.toString().toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
}
