package com.challenge.videorank.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import android.widget.VideoView
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.challenge.videorank.audio.BeatMap
import com.challenge.videorank.audio.PlaybackClock
import com.challenge.videorank.data.VideoEntity
import com.challenge.videorank.ui.components.BeatBar
import com.challenge.videorank.ui.components.colorForLevel
import com.challenge.videorank.ui.theme.DangerRed
import com.challenge.videorank.ui.theme.NeonCyan
import com.challenge.videorank.ui.theme.NeonGold
import com.challenge.videorank.viewmodel.GameViewModel
import com.challenge.videorank.viewmodel.TOTAL_LEVELS
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

/** How long the GTA-style loading screen stays on screen for a normal level. */
private const val LEVEL_TRANSITION_MS = 9000L

/** The secret boss encounter gets an even longer, more dramatic loading screen. */
private const val BOSS_TRANSITION_MS = 11000L

/** How long each background still is shown before cross-fading to the next one. */
private const val FRAME_SWAP_MS = 1100L

/** Chance, per level transition, that the surprise secret boss level fires. Fires at most once per run. */
private const val BOSS_CHANCE = 0.25f

/** Flavor-text tips shown on the loading screen, picked at random each time. */
private val LOADING_TIPS = listOf(
    "CONSEJO: cuanto más subes de nivel, más difícil se pone el vídeo.",
    "CONSEJO: pulsa RENDIRSE solo si de verdad quieres abandonar la partida.",
    "DATO: hay 10 niveles en total, del más fácil al más difícil.",
    "CONSEJO: puedes reordenar los niveles desde \"Editar niveles\" en el menú.",
    "DATO: el color de cada nivel indica su dificultad — verde es fácil, rojo es difícil.",
    "CONSEJO: si fallas, puedes reintentar el reto desde el nivel 1.",
    "CONSEJO: mantente enfocado.",
    "CONSEJO: respira por la nariz, suelta por la boca."
)

/** Flavor-text shown instead of a normal tip when the secret boss level is about to start. */
private val BOSS_TIPS = listOf(
    "ALERTA: un reto inesperado se acerca. No bajes la guardia.",
    "ALERTA: esto no estaba en el plan. Prepárate.",
    "ALERTA: nivel no catalogado detectado. Máxima dificultad."
)

private enum class GameStatus { LOADING, PLAYING, GAME_OVER, VICTORY }

@Composable
fun GameScreen(viewModel: GameViewModel, onExit: () -> Unit) {
    var currentLevel by remember { mutableStateOf(1) }
    var status by remember { mutableStateOf(GameStatus.LOADING) }
    var loadingProgress by remember { mutableStateOf(0f) }
    var loadingTargetLevel by remember { mutableStateOf(1) }
    var isBossTransition by remember { mutableStateOf(false) }
    var currentLevelIsBoss by remember { mutableStateOf(false) }
    var bossUsedThisRun by remember { mutableStateOf(false) }

    val video = remember(currentLevel, status) {
        if (status == GameStatus.PLAYING) viewModel.videoForLevel(currentLevel) else null
    }

    fun restart() {
        currentLevel = 1
        loadingTargetLevel = 1
        isBossTransition = false
        currentLevelIsBoss = false
        bossUsedThisRun = false
        status = GameStatus.LOADING
    }

    // Shows a GTA-style "loading" screen before the first level and between every
    // later level, instead of jumping straight into a video. Also where the
    // level actually advances once the loading screen finishes.
    LaunchedEffect(status) {
        if (status == GameStatus.LOADING) {
            loadingProgress = 0f
            val durationMs = if (isBossTransition) BOSS_TRANSITION_MS else LEVEL_TRANSITION_MS
            val steps = 100
            val stepDelay = durationMs / steps
            for (i in 1..steps) {
                delay(stepDelay)
                loadingProgress = i / steps.toFloat()
            }
            currentLevel = loadingTargetLevel
            currentLevelIsBoss = isBossTransition
            status = GameStatus.PLAYING
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        when (status) {
            GameStatus.PLAYING -> {
                if (video == null) {
                    MissingVideoMessage(level = currentLevel, onExit = onExit)
                } else {
                    val playbackClock = remember(video.id) { PlaybackClock() }
                    var beatMap by remember(video.id) { mutableStateOf<BeatMap?>(null) }

                    // Analyze this video's real audio once (cached after the first time)
                    // so the beat bar can sync to its actual rhythm, not a live guess.
                    LaunchedEffect(video.id) {
                        beatMap = viewModel.beatMapFor(video)
                    }

                    key(video.id) {
                        LevelVideoPlayer(
                            video = video,
                            playbackClock = playbackClock,
                            modifier = Modifier.fillMaxSize(),
                            onCompleted = {
                                if (currentLevel >= TOTAL_LEVELS) {
                                    status = GameStatus.VICTORY
                                } else {
                                    loadingTargetLevel = currentLevel + 1
                                    isBossTransition = !bossUsedThisRun && Random.nextFloat() < BOSS_CHANCE
                                    if (isBossTransition) bossUsedThisRun = true
                                    status = GameStatus.LOADING
                                }
                            }
                        )
                    }

                    GameHud(
                        currentLevel = currentLevel,
                        isBoss = currentLevelIsBoss,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                    )

                    // Rhythm bar reacting to the video's own audio in real time, tucked
                    // above the surrender button so the two don't collide.
                    BeatBar(
                        beatMap = beatMap,
                        playbackClock = playbackClock,
                        level = currentLevel,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(start = 20.dp, end = 20.dp, bottom = 56.dp)
                            .height(48.dp)
                    )

                    // Small, out-of-the-way surrender button tucked into the corner so it
                    // doesn't sit on top of the video.
                    Button(
                        onClick = { status = GameStatus.GAME_OVER },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed.copy(alpha = 0.85f)),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 14.dp, bottom = 14.dp)
                    ) {
                        Text("RENDIRSE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }

            GameStatus.LOADING -> LoadingNextLevelOverlay(
                nextLevel = loadingTargetLevel,
                nextVideo = viewModel.videoForLevel(loadingTargetLevel),
                viewModel = viewModel,
                progress = loadingProgress,
                isBoss = isBossTransition
            )

            GameStatus.GAME_OVER -> GameOverOverlay(
                level = currentLevel,
                onRetry = { restart() },
                onExit = onExit
            )

            GameStatus.VICTORY -> VictoryOverlay(
                onReplay = { restart() },
                onExit = onExit
            )
        }
    }
}

@Composable
private fun GameHud(currentLevel: Int, isBoss: Boolean, modifier: Modifier = Modifier) {
    val labelColor = if (isBoss) DangerRed else colorForLevel(currentLevel)
    val label = if (isBoss) "☠ JEFE SECRETO · NIVEL $currentLevel" else "NIVEL $currentLevel / $TOTAL_LEVELS"

    Column(
        modifier = modifier
            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.45f), Color.Transparent)))
            .padding(top = 10.dp, bottom = 14.dp, start = 16.dp, end = 16.dp)
    ) {
        Text(
            label,
            color = labelColor,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(5.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            for (level in 1..TOTAL_LEVELS) {
                val color = if (isBoss) DangerRed else colorForLevel(level)
                Box(
                    modifier = Modifier
                        .padding(horizontal = 2.dp)
                        .size(6.dp)
                        .background(
                            if (level <= currentLevel) color else Color.White.copy(alpha = 0.15f),
                            CircleShape
                        )
                )
            }
        }
    }
}

@Composable
private fun LevelVideoPlayer(
    video: VideoEntity,
    playbackClock: PlaybackClock,
    onCompleted: () -> Unit,
    modifier: Modifier = Modifier
) {
    var videoView by remember(video.id) { mutableStateOf<VideoView?>(null) }

    // Keeps the playback clock in sync with where the video really is, so the
    // beat bar can place notes against the real timeline of its audio.
    LaunchedEffect(video.id) {
        while (isActive) {
            videoView?.let { vv ->
                if (vv.isPlaying) playbackClock.sync(vv.currentPosition.toLong())
            }
            delay(100)
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            VideoView(ctx).apply {
                setVideoURI(Uri.parse(video.uri))
                setOnPreparedListener { mp ->
                    mp.isLooping = false
                    start()
                }
                setOnCompletionListener { onCompleted() }
                setOnErrorListener { _, _, _ ->
                    // Skip forward instead of getting stuck on a video that won't play.
                    onCompleted()
                    true
                }
                videoView = this
            }
        },
        onRelease = { view -> view.stopPlayback() }
    )
}

/**
 * GTA-style loading screen shown before the first level and between every later
 * one: real stills from the upcoming video cross-fade in the background behind
 * a dark vignette, with a big level title, a rotating tip and a progress bar.
 *
 * When [isBoss] is true this becomes the surprise "secret boss" encounter: the
 * frames get a red tint, the title turns into "JEFE SECRETO" in red with a
 * pulsing glow, and the whole screen runs longer to build tension.
 */
@Composable
private fun LoadingNextLevelOverlay(
    nextLevel: Int,
    nextVideo: VideoEntity?,
    viewModel: GameViewModel,
    progress: Float,
    isBoss: Boolean
) {
    val color = if (isBoss) DangerRed else colorForLevel(nextLevel.coerceAtMost(TOTAL_LEVELS))
    val tip = remember(nextLevel, isBoss) {
        if (isBoss) BOSS_TIPS.random() else LOADING_TIPS.random()
    }

    var frames by remember(nextVideo?.id) { mutableStateOf<List<Bitmap>>(emptyList()) }
    var frameIndex by remember(nextVideo?.id) { mutableStateOf(0) }

    LaunchedEffect(nextVideo?.id) {
        frameIndex = 0
        frames = nextVideo?.let { viewModel.framesFor(it) } ?: emptyList()
    }

    LaunchedEffect(frames) {
        if (frames.size <= 1) return@LaunchedEffect
        while (true) {
            delay(FRAME_SWAP_MS)
            frameIndex = (frameIndex + 1) % frames.size
        }
    }

    // Pulsing glow used only for the boss encounter's epic treatment.
    val infiniteTransition = rememberInfiniteTransition(label = "bossPulse")
    val bossGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(tween(550), RepeatMode.Reverse),
        label = "bossGlowAlpha"
    )
    val bossTitleScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "bossTitleScale"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        // Background: real frames from the next video, cross-fading like a GTA
        // loading screen slideshow. A red multiply tint is applied for the boss
        // encounter. Falls back to a plain gradient while frames are still being
        // extracted (or if the video can't be read).
        Crossfade(
            targetState = frames.getOrNull(frameIndex),
            animationSpec = tween(700),
            label = "loadingFrame"
        ) { frame ->
            if (frame != null) {
                Image(
                    bitmap = frame.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    colorFilter = if (isBoss) {
                        ColorFilter.tint(DangerRed.copy(alpha = 0.45f), BlendMode.Multiply)
                    } else {
                        null
                    }
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            if (isBoss) {
                                Brush.radialGradient(listOf(DangerRed.copy(alpha = 0.4f), Color.Black))
                            } else {
                                Brush.radialGradient(listOf(Color(0xFF1A1730), Color.Black))
                            }
                        )
                )
            }
        }

        // Top-to-bottom vignette so the HUD text stays legible over any footage.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = 0.78f),
                        0.3f to Color.Black.copy(alpha = 0.1f),
                        0.7f to Color.Black.copy(alpha = 0.25f),
                        1f to Color.Black.copy(alpha = 0.92f)
                    )
                )
        )
        // Side vignette for extra contrast behind the corner labels.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        0f to Color.Black.copy(alpha = 0.5f),
                        0.5f to Color.Transparent,
                        1f to Color.Black.copy(alpha = 0.5f)
                    )
                )
        )

        if (isBoss) {
            // Extra pulsing red glow around the edges for the "epic" boss feel.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(Color.Transparent, DangerRed.copy(alpha = bossGlowAlpha))
                        )
                    )
            )
        }

        Text(
            if (isBoss) "⚠ ALERTA" else "CARGANDO",
            color = if (isBoss) DangerRed else Color.White.copy(alpha = 0.55f),
            fontWeight = FontWeight.Bold,
            letterSpacing = 4.sp,
            fontSize = 12.sp,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 24.dp, top = 24.dp)
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(0.88f)
                .padding(start = 24.dp, end = 24.dp, bottom = 28.dp)
        ) {
            if (isBoss) {
                Text(
                    "JEFE SECRETO",
                    color = DangerRed,
                    fontWeight = FontWeight.Black,
                    fontSize = 40.sp,
                    modifier = Modifier.scale(bossTitleScale)
                )
                Text(
                    "NIVEL $nextLevel",
                    color = Color.White.copy(alpha = 0.85f),
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            } else {
                Text(
                    "NIVEL $nextLevel",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 42.sp
                )
            }
            Box(
                modifier = Modifier
                    .padding(top = 6.dp)
                    .size(width = 72.dp, height = 4.dp)
                    .background(color)
            )
            Spacer(Modifier.height(14.dp))
            Text(
                tip,
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
            Spacer(Modifier.height(18.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.15f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress.coerceIn(0f, 1f))
                        .clip(RoundedCornerShape(50))
                        .background(color)
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "${(progress * 100).toInt()}%",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun MissingVideoMessage(level: Int, onExit: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "El nivel $level no tiene un vídeo asignado",
                color = Color.White,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onExit) {
                Text("Volver al menú", color = Color.White)
            }
        }
    }
}

@Composable
private fun GameOverOverlay(level: Int, onRetry: () -> Unit, onExit: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.92f)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("HAS FALLADO", color = DangerRed, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "Llegaste al nivel $level de $TOTAL_LEVELS",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 15.sp
            )
            Spacer(Modifier.height(32.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                modifier = Modifier.fillMaxWidth(0.7f)
            ) {
                Text("REINTENTAR", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onExit, modifier = Modifier.fillMaxWidth(0.7f)) {
                Text("Volver al menú", color = Color.White)
            }
        }
    }
}

@Composable
private fun VictoryOverlay(onReplay: () -> Unit, onExit: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "victoryPulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.92f)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .scale(pulse)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.radialGradient(listOf(NeonGold, Color.Transparent)))
                    .border(1.dp, NeonGold.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                    .padding(28.dp)
            ) {
                Text(
                    "🏆",
                    fontSize = 48.sp
                )
            }
            Spacer(Modifier.height(16.dp))
            Text("¡RETO COMPLETADO!", color = NeonGold, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
            Text(
                "Superaste los $TOTAL_LEVELS niveles",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 15.sp
            )
            Spacer(Modifier.height(32.dp))
            Button(
                onClick = onReplay,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGold),
                modifier = Modifier.fillMaxWidth(0.7f)
            ) {
                Text("JUGAR DE NUEVO", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onExit, modifier = Modifier.fillMaxWidth(0.7f)) {
                Text("Volver al menú", color = Color.White)
            }
        }
    }
}
