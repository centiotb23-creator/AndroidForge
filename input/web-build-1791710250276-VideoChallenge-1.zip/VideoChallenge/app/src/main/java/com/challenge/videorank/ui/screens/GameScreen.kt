package com.challenge.videorank.ui.screens

import android.net.Uri
import android.widget.VideoView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.challenge.videorank.data.VideoEntity
import com.challenge.videorank.ui.components.colorForLevel
import com.challenge.videorank.ui.theme.DangerRed
import com.challenge.videorank.ui.theme.NeonCyan
import com.challenge.videorank.ui.theme.NeonGold
import com.challenge.videorank.viewmodel.GameViewModel
import com.challenge.videorank.viewmodel.TOTAL_LEVELS
import kotlinx.coroutines.delay

/** How long the "loading next level" transition stays on screen. */
private const val LEVEL_TRANSITION_MS = 1200L

private enum class GameStatus { PLAYING, LOADING_NEXT, GAME_OVER, VICTORY }

@Composable
fun GameScreen(viewModel: GameViewModel, onExit: () -> Unit) {
    var currentLevel by remember { mutableStateOf(1) }
    var status by remember { mutableStateOf(GameStatus.PLAYING) }

    val video = remember(currentLevel, status) {
        if (status == GameStatus.PLAYING) viewModel.videoForLevel(currentLevel) else null
    }

    fun restart() {
        currentLevel = 1
        status = GameStatus.PLAYING
    }

    // Briefly shows a "loading" screen between levels instead of jumping straight
    // into the next video, then advances the level and resumes playback.
    LaunchedEffect(status) {
        if (status == GameStatus.LOADING_NEXT) {
            delay(LEVEL_TRANSITION_MS)
            currentLevel += 1
            status = GameStatus.PLAYING
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        when (status) {
            GameStatus.PLAYING -> {
                if (video == null) {
                    MissingVideoMessage(level = currentLevel, onExit = onExit)
                } else {
                    key(video.id) {
                        LevelVideoPlayer(
                            video = video,
                            modifier = Modifier.fillMaxSize(),
                            onCompleted = {
                                status = if (currentLevel >= TOTAL_LEVELS) {
                                    GameStatus.VICTORY
                                } else {
                                    GameStatus.LOADING_NEXT
                                }
                            }
                        )
                    }

                    GameHud(
                        currentLevel = currentLevel,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                    )

                    // Small, out-of-the-way surrender button tucked into the corner so it
                    // doesn't sit on top of the video.
                    Button(
                        onClick = { status = GameStatus.GAME_OVER },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed.copy(alpha = 0.85f)),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 14.dp, bottom = 14.dp)
                    ) {
                        Text("RENDIRSE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }

            GameStatus.LOADING_NEXT -> LoadingNextLevelOverlay(nextLevel = currentLevel + 1)

            GameStatus.GAME_OVER -> GameOverOverlay(
                level = currentLevel,
                onRetry = { restart() },
                onExit = onExit
            )

            GameStatus.VICTORY -> VictoryOverlay(
                onReplay = { restart() },
                onExit = onExit
            )
        }
    }
}

@Composable
private fun GameHud(currentLevel: Int, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)))
            .padding(top = 16.dp, bottom = 24.dp, start = 16.dp, end = 16.dp)
    ) {
        Text(
            "NIVEL $currentLevel / $TOTAL_LEVELS",
            color = colorForLevel(currentLevel),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 18.sp,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            for (level in 1..TOTAL_LEVELS) {
                val color = colorForLevel(level)
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .size(10.dp)
                        .background(
                            if (level <= currentLevel) color else Color.White.copy(alpha = 0.15f),
                            CircleShape
                        )
                )
            }
        }
    }
}

@Composable
private fun LevelVideoPlayer(
    video: VideoEntity,
    onCompleted: () -> Unit,
    modifier: Modifier = Modifier
) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            VideoView(ctx).apply {
                setVideoURI(Uri.parse(video.uri))
                setOnPreparedListener { mp ->
                    mp.isLooping = false
                    start()
                }
                setOnCompletionListener { onCompleted() }
                setOnErrorListener { _, _, _ ->
                    // Skip forward instead of getting stuck on a video that won't play.
                    onCompleted()
                    true
                }
            }
        },
        onRelease = { view -> view.stopPlayback() }
    )
}

/**
 * Shown for a beat between levels instead of cutting straight to the next video,
 * so a rotation or a quick level change doesn't feel like a jarring jump cut.
 */
@Composable
private fun LoadingNextLevelOverlay(nextLevel: Int) {
    val color = colorForLevel(nextLevel.coerceAtMost(TOTAL_LEVELS))
    val infiniteTransition = rememberInfiniteTransition(label = "loadingSpin")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing)),
        label = "rotation"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .rotate(rotation)
                    .border(
                        width = 4.dp,
                        brush = Brush.sweepGradient(listOf(color, Color.Transparent, color)),
                        shape = CircleShape
                    )
            )
            Spacer(Modifier.height(20.dp))
            Text(
                "NIVEL $nextLevel",
                color = color,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Cargando siguiente reto…",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun MissingVideoMessage(level: Int, onExit: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "El nivel $level no tiene un vídeo asignado",
                color = Color.White,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onExit) {
                Text("Volver al menú", color = Color.White)
            }
        }
    }
}

@Composable
private fun GameOverOverlay(level: Int, onRetry: () -> Unit, onExit: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.92f)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("HAS FALLADO", color = DangerRed, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "Llegaste al nivel $level de $TOTAL_LEVELS",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 15.sp
            )
            Spacer(Modifier.height(32.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                modifier = Modifier.fillMaxWidth(0.7f)
            ) {
                Text("REINTENTAR", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onExit, modifier = Modifier.fillMaxWidth(0.7f)) {
                Text("Volver al menú", color = Color.White)
            }
        }
    }
}

@Composable
private fun VictoryOverlay(onReplay: () -> Unit, onExit: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "victoryPulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.92f)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .scale(pulse)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.radialGradient(listOf(NeonGold, Color.Transparent)))
                    .border(1.dp, NeonGold.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                    .padding(28.dp)
            ) {
                Text(
                    "🏆",
                    fontSize = 48.sp
                )
            }
            Spacer(Modifier.height(16.dp))
            Text("¡RETO COMPLETADO!", color = NeonGold, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
            Text(
                "Superaste los $TOTAL_LEVELS niveles",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 15.sp
            )
            Spacer(Modifier.height(32.dp))
            Button(
                onClick = onReplay,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGold),
                modifier = Modifier.fillMaxWidth(0.7f)
            ) {
                Text("JUGAR DE NUEVO", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onExit, modifier = Modifier.fillMaxWidth(0.7f)) {
                Text("Volver al menú", color = Color.White)
            }
        }
    }
}
