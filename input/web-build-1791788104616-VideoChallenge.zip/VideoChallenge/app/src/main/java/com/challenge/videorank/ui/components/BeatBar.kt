package com.challenge.videorank.ui.components

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.challenge.videorank.audio.BeatDetector
import kotlin.math.sin

/** Where the fixed "hit circle" sits, as a fraction of the bar's width — dead center. */
private const val HIT_X_FRACTION = 0.5f

/** How many upcoming beats are shown approaching at once, for a "stream" of circles. */
private const val VISIBLE_NOTES = 4

/** Starting tempo guess (ms between beats) before any real beat has been detected yet. */
private const val DEFAULT_INTERVAL_MS = 500L

/** How many recent real intervals are kept to estimate the current tempo. */
private const val INTERVAL_HISTORY = 8

/**
 * A rhythm-game-style bar: circles travel from the right edge toward a fixed
 * "hit circle" in the middle, timed to arrive right when the next beat of the
 * video's own audio is expected, then keep drifting on through to the left
 * edge as they fade — so they visibly "pass through" the hit circle instead
 * of just vanishing on it. The hit circle keeps a subtle continuous pulse in
 * time with the music's loudness, and flashes brighter exactly when a beat
 * lands.
 *
 * The tempo isn't a fixed speed: every real detected beat refines a rolling
 * estimate (the median of the last few real intervals), so the circles speed
 * up or slow down as the actual song does.
 *
 * Works even if [detector] is null or Visualizer isn't available: it falls
 * back to a steady decorative pulse instead of disappearing.
 */
@Composable
fun BeatBar(detector: BeatDetector?, modifier: Modifier = Modifier) {
    val liveEnergy by (detector?.liveEnergy?.collectAsState(initial = 0f)
        ?: remember { mutableFloatStateOf(0f) })

    var estimatedIntervalMs by remember { mutableLongStateOf(DEFAULT_INTERVAL_MS) }
    var nextBeatAt by remember { mutableLongStateOf(SystemClock.elapsedRealtime() + DEFAULT_INTERVAL_MS) }
    var lastRealBeatAt by remember { mutableLongStateOf(0L) }
    var hitFlash by remember { mutableFloatStateOf(0f) }
    var nowElapsed by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    val recentIntervals = remember { mutableStateOf(ArrayDeque<Long>()) }

    // Resync to the real audio whenever a genuine beat is detected: refine the
    // tempo estimate from the actual recent rhythm and snap the next expected
    // beat to real playback, so the bar tracks what's really playing instead
    // of ticking at one constant speed.
    LaunchedEffect(detector) {
        val events = detector?.beatEvents ?: return@LaunchedEffect
        events.collect { t ->
            if (lastRealBeatAt != 0L) {
                val interval = t - lastRealBeatAt
                if (interval in 220..1800) {
                    val history = recentIntervals.value
                    history.addLast(interval)
                    while (history.size > INTERVAL_HISTORY) history.removeFirst()
                    // The median of recent real intervals tracks the song's actual
                    // tempo and shrugs off the occasional missed/extra onset, while
                    // still following the music if it speeds up or slows down.
                    val sorted = history.sorted()
                    estimatedIntervalMs = sorted[sorted.size / 2]
                }
            }
            lastRealBeatAt = t
            nextBeatAt = t + estimatedIntervalMs
            hitFlash = 1f
        }
    }

    // Drives the animation every frame: advances the beat schedule on its own
    // when no fresh detection has arrived yet (so the bar never goes static),
    // and decays the hit flash after each pulse.
    LaunchedEffect(Unit) {
        while (true) {
            withFrameMillis { }
            val now = SystemClock.elapsedRealtime()
            nowElapsed = now
            while (now >= nextBeatAt) {
                nextBeatAt += estimatedIntervalMs
                hitFlash = 1f
            }
            hitFlash = (hitFlash - 0.045f).coerceAtLeast(0f)
        }
    }

    val idlePulse = 0.5f + 0.5f * sin(nowElapsed / 260f)
    val energyPulse = (liveEnergy * 1.4f).coerceIn(0f, 1f)

    Canvas(modifier = modifier.fillMaxSize()) {
        val hitX = size.width * HIT_X_FRACTION
        val centerY = size.height / 2f
        val laneColor = Color.White.copy(alpha = 0.12f)

        // Lane line the notes travel along, full width.
        drawLine(
            color = laneColor,
            start = Offset(0f, centerY),
            end = Offset(size.width, centerY),
            strokeWidth = 2.dp.toPx()
        )

        // Notes travel from the right edge toward the hit circle (anticipation),
        // then keep drifting on to the left edge while fading (the "pass through").
        // k = -1 is the most recently hit note, still finishing its pass-through.
        val entryDuration = estimatedIntervalMs
        val exitDuration = (estimatedIntervalMs * 0.4f).toLong().coerceAtLeast(90L)

        for (k in -1 until VISIBLE_NOTES) {
            val hitAt = nextBeatAt + k * estimatedIntervalMs
            val spawnAt = hitAt - entryDuration
            val vanishAt = hitAt + exitDuration
            if (nowElapsed < spawnAt || nowElapsed > vanishAt) continue

            val x: Float
            val alpha: Float
            val radius: Float
            if (nowElapsed <= hitAt) {
                val progress = ((nowElapsed - spawnAt).toFloat() / entryDuration).coerceIn(0f, 1f)
                x = size.width - progress * (size.width - hitX)
                alpha = (0.35f + 0.65f * progress) * (1f - k.coerceAtLeast(0) * 0.18f).coerceAtLeast(0.25f)
                radius = 8.dp.toPx() * (0.75f + 0.25f * progress)
            } else {
                val progress = ((nowElapsed - hitAt).toFloat() / exitDuration).coerceIn(0f, 1f)
                x = hitX - progress * hitX
                alpha = (1f - progress)
                radius = 8.dp.toPx() * (1f - 0.2f * progress)
            }

            drawCircle(
                color = Color(0xFF00E5FF).copy(alpha = alpha.coerceIn(0f, 1f)),
                radius = radius,
                center = Offset(x, centerY)
            )
        }

        // The hit circle: a steady idle pulse driven by the music's loudness
        // (or a gentle decorative sway if there's no audio signal), plus a
        // sharp flash exactly on each beat.
        val baseRadius = 12.dp.toPx()
        val hitRadius = baseRadius * (1f + idlePulse * 0.1f + energyPulse * 0.25f + hitFlash * 0.6f)
        val hitColor = Color(0xFFFF4D8D)

        if (hitFlash > 0.05f) {
            drawCircle(
                color = hitColor.copy(alpha = hitFlash * 0.35f),
                radius = hitRadius + 14.dp.toPx() * hitFlash,
                center = Offset(hitX, centerY)
            )
        }
        drawCircle(
            color = hitColor.copy(alpha = 0.9f),
            radius = hitRadius,
            center = Offset(hitX, centerY)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.6f + hitFlash * 0.4f),
            radius = hitRadius,
            center = Offset(hitX, centerY),
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}
