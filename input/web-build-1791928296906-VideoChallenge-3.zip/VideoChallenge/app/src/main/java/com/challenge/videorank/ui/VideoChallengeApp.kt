package com.challenge.videorank.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.challenge.videorank.ui.screens.GameScreen
import com.challenge.videorank.ui.screens.HomeScreen
import com.challenge.videorank.ui.screens.LevelEditorScreen
import com.challenge.videorank.viewmodel.GameViewModel

private object Routes {
    const val HOME = "home"
    const val LEVEL_EDITOR = "level_editor"
    const val GAME = "game"
    const val GAME_RANDOM = "game_random"
}

@Composable
fun VideoChallengeApp(viewModel: GameViewModel) {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                viewModel = viewModel,
                onEditLevels = { navController.navigate(Routes.LEVEL_EDITOR) },
                onPlay = { navController.navigate(Routes.GAME) },
                onPlayRandom = { navController.navigate(Routes.GAME_RANDOM) }
            )
        }
        composable(Routes.LEVEL_EDITOR) {
            LevelEditorScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.GAME) {
            GameScreen(
                viewModel = viewModel,
                onExit = { navController.popBackStack() }
            )
        }
        composable(Routes.GAME_RANDOM) {
            GameScreen(
                viewModel = viewModel,
                randomMode = true,
                onExit = { navController.popBackStack() }
            )
        }
    }
}
