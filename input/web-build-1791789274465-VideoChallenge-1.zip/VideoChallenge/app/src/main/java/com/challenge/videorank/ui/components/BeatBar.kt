package com.challenge.videorank.ui.components

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.challenge.videorank.audio.BeatDetector
import kotlin.math.sin

/** Where the fixed "hit circle" sits, as a fraction of the bar's width — dead center. */
private const val HIT_X_FRACTION = 0.5f

/** Starting tempo guess (ms between beats) before any real beat has been detected yet. */
private const val DEFAULT_INTERVAL_MS = 650L

/** The tempo estimate is never allowed to drift outside a believable musical range. */
private const val MIN_INTERVAL_MS = 340L
private const val MAX_INTERVAL_MS = 950L

/** How many recent real intervals are kept to estimate the current tempo. */
private const val INTERVAL_HISTORY = 8

/** How many beats ahead a note becomes visible — bigger = slower, calmer approach. */
private const val LEAD_BEATS = 2.2f

/** How often a new waveform sample is pushed into the scrolling history, in ms. */
private const val WAVEFORM_SAMPLE_MS = 35L

/** How many waveform bars are kept (covers the full width of the bar). */
private const val WAVEFORM_BARS = 140

/**
 * A rhythm-game-style bar with two layers:
 *
 * - A scrolling waveform in the background, built straight from the video's
 *   real, continuously-measured loudness — it never sits still or repeats on
 *   a fixed schedule, because it's a direct trace of the actual sound.
 * - A fixed "hit circle" in the middle that a stream of notes approaches from
 *   the right, timed to arrive on each real detected beat, then drifts on
 *   through to the left while fading — so they visibly pass through it. The
 *   gap between notes follows the song's estimated tempo (clamped to a
 *   believable range and smoothed so it doesn't jitter), and [level] adds
 *   more simultaneous notes as the challenge gets harder.
 *
 * Works even if [detector] is null or Visualizer isn't available: both layers
 * fall back to a gentle decorative animation instead of disappearing.
 */
@Composable
fun BeatBar(detector: BeatDetector?, level: Int, modifier: Modifier = Modifier) {
    val liveEnergy by (detector?.liveEnergy?.collectAsState(initial = 0f)
        ?: remember { mutableFloatStateOf(0f) })

    var estimatedIntervalMs by remember { mutableLongStateOf(DEFAULT_INTERVAL_MS) }
    var nextBeatAt by remember { mutableLongStateOf(SystemClock.elapsedRealtime() + DEFAULT_INTERVAL_MS) }
    var lastRealBeatAt by remember { mutableLongStateOf(0L) }
    var hitFlash by remember { mutableFloatStateOf(0f) }
    var nowElapsed by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    val recentIntervals = remember { ArrayDeque<Long>() }
    val waveform = remember { ArrayDeque<Float>().apply { repeat(WAVEFORM_BARS) { addLast(0f) } } }
    var lastWaveformSampleAt by remember { mutableLongStateOf(0L) }

    // More notes approaching at once as the run gets harder — levels 1-10 map
    // to roughly 2..6 simultaneous notes in the stream.
    val visibleNotes = (2 + level / 2).coerceIn(2, 6)

    // Resync to the real audio whenever a genuine beat is detected: refine the
    // tempo estimate from the actual recent rhythm (median of recent real
    // intervals, clamped to a believable range and only allowed to shift
    // gradually) so the bar follows the song without jittering wildly.
    LaunchedEffect(detector) {
        val events = detector?.beatEvents ?: return@LaunchedEffect
        events.collect { t ->
            if (lastRealBeatAt != 0L) {
                val interval = (t - lastRealBeatAt).coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)
                recentIntervals.addLast(interval)
                while (recentIntervals.size > INTERVAL_HISTORY) recentIntervals.removeFirst()
                val sorted = recentIntervals.sorted()
                val target = sorted[sorted.size / 2]
                // Slew-limited: the apparent tempo can drift toward the real one,
                // but never jumps there in a single beat, which is what made the
                // bar feel erratic instead of merely "a bit" varied.
                val maxStep = (estimatedIntervalMs * 0.12f).toLong().coerceAtLeast(15L)
                estimatedIntervalMs = when {
                    target > estimatedIntervalMs -> (estimatedIntervalMs + maxStep).coerceAtMost(target)
                    target < estimatedIntervalMs -> (estimatedIntervalMs - maxStep).coerceAtLeast(target)
                    else -> estimatedIntervalMs
                }.coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)
            }
            lastRealBeatAt = t
            nextBeatAt = t + estimatedIntervalMs
            hitFlash = 1f
        }
    }

    // Drives the animation every frame: advances the beat schedule on its own
    // when no fresh detection has arrived yet (so the bar never goes static),
    // decays the hit flash, and pushes a fresh waveform sample on a timer.
    LaunchedEffect(Unit) {
        while (true) {
            withFrameMillis { }
            val now = SystemClock.elapsedRealtime()
            nowElapsed = now
            while (now >= nextBeatAt) {
                nextBeatAt += estimatedIntervalMs
                hitFlash = 1f
            }
            hitFlash = (hitFlash - 0.045f).coerceAtLeast(0f)

            if (now - lastWaveformSampleAt >= WAVEFORM_SAMPLE_MS) {
                lastWaveformSampleAt = now
                // Real audio drives the trace; with no signal, a slow gentle sway
                // keeps it from reading as broken.
                val sample = if (detector != null) {
                    liveEnergy.coerceIn(0f, 1f)
                } else {
                    0.18f + 0.12f * sin(now / 420f)
                }
                waveform.addLast(sample)
                if (waveform.size > WAVEFORM_BARS) waveform.removeFirst()
            }
        }
    }

    val idlePulse = 0.5f + 0.5f * sin(nowElapsed / 260f)
    val energyPulse = (liveEnergy * 1.4f).coerceIn(0f, 1f)

    Canvas(modifier = modifier.fillMaxSize()) {
        val hitX = size.width * HIT_X_FRACTION
        val centerY = size.height / 2f

        // Scrolling waveform: a direct trace of the video's own loudness over
        // the last few seconds, oldest on the left, newest on the right.
        val barGap = size.width / WAVEFORM_BARS
        val barWidth = (barGap * 0.55f).coerceAtLeast(1f)
        val maxBarHeight = size.height * 0.4f
        waveform.forEachIndexed { index, amplitude ->
            val x = index * barGap + barGap / 2f
            val h = (amplitude.coerceIn(0f, 1f) * maxBarHeight).coerceAtLeast(2f)
            val distanceFromHit = kotlin.math.abs(x - hitX) / size.width
            val alpha = (0.5f - distanceFromHit * 0.4f).coerceIn(0.12f, 0.5f)
            drawLine(
                color = Color(0xFFE056C4).copy(alpha = alpha),
                start = Offset(x, centerY - h / 2f),
                end = Offset(x, centerY + h / 2f),
                strokeWidth = barWidth
            )
        }

        // Vertical marker through the whole lane, like a playhead, so the hit
        // point reads clearly even against the waveform underneath it.
        drawLine(
            color = Color.White.copy(alpha = 0.18f),
            start = Offset(hitX, 0f),
            end = Offset(hitX, size.height),
            strokeWidth = 1.5.dp.toPx()
        )

        // Notes travel from the right edge toward the hit circle (anticipation),
        // then keep drifting on to the left edge while fading (the "pass through").
        // k = -1 is the most recently hit note, still finishing its pass-through.
        val entryDuration = (estimatedIntervalMs * LEAD_BEATS).toLong()
        val exitDuration = (estimatedIntervalMs * 0.45f).toLong().coerceAtLeast(100L)
        val beatSpacing = entryDuration / LEAD_BEATS // == estimatedIntervalMs, kept explicit for clarity

        for (k in -1 until visibleNotes) {
            val hitAt = nextBeatAt + k * beatSpacing.toLong()
            val spawnAt = hitAt - entryDuration
            val vanishAt = hitAt + exitDuration
            if (nowElapsed < spawnAt || nowElapsed > vanishAt) continue

            val x: Float
            val alpha: Float
            val radius: Float
            if (nowElapsed <= hitAt) {
                val progress = ((nowElapsed - spawnAt).toFloat() / entryDuration).coerceIn(0f, 1f)
                x = size.width - progress * (size.width - hitX)
                alpha = (0.35f + 0.65f * progress) * (1f - k.coerceAtLeast(0) * 0.12f).coerceAtLeast(0.35f)
                radius = 7.dp.toPx() * (0.75f + 0.25f * progress)
            } else {
                val progress = ((nowElapsed - hitAt).toFloat() / exitDuration).coerceIn(0f, 1f)
                x = hitX - progress * hitX
                alpha = (1f - progress)
                radius = 7.dp.toPx() * (1f - 0.2f * progress)
            }

            drawCircle(
                color = Color(0xFF00E5FF).copy(alpha = alpha.coerceIn(0f, 1f)),
                radius = radius,
                center = Offset(x, centerY)
            )
        }

        // The hit circle: a steady idle pulse driven by the music's loudness
        // (or a gentle decorative sway if there's no audio signal), plus a
        // sharp flash exactly on each beat.
        val baseRadius = 11.dp.toPx()
        val hitRadius = baseRadius * (1f + idlePulse * 0.1f + energyPulse * 0.25f + hitFlash * 0.55f)
        val hitColor = Color(0xFFFF4D8D)

        if (hitFlash > 0.05f) {
            drawCircle(
                color = hitColor.copy(alpha = hitFlash * 0.35f),
                radius = hitRadius + 13.dp.toPx() * hitFlash,
                center = Offset(hitX, centerY)
            )
        }
        drawCircle(
            color = hitColor.copy(alpha = 0.9f),
            radius = hitRadius,
            center = Offset(hitX, centerY)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.6f + hitFlash * 0.4f),
            radius = hitRadius,
            center = Offset(hitX, centerY),
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}
