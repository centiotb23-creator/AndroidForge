package com.challenge.videorank.ui.components

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.challenge.videorank.audio.BeatDetector
import kotlin.math.sin

/** How far from the left edge the "hit circle" sits, as a fraction of the bar's width. */
private const val HIT_X_FRACTION = 0.14f

/** How many upcoming beats are shown approaching at once, for a "stream" of circles. */
private const val VISIBLE_NOTES = 3

/** Starting tempo guess (ms between beats) before any real beat has been detected yet. */
private const val DEFAULT_INTERVAL_MS = 500L

/**
 * A rhythm-game-style bar: circles travel from the right edge toward a fixed
 * "hit circle" on the left, timed to arrive right when the next beat of the
 * video's own audio is expected. The hit circle itself keeps a subtle
 * continuous pulse in time with the music's loudness, and flashes brighter
 * whenever a beat actually lands.
 *
 * Works even if [detector] is null or Visualizer isn't available: it falls
 * back to a steady decorative pulse instead of disappearing.
 */
@Composable
fun BeatBar(detector: BeatDetector?, modifier: Modifier = Modifier) {
    val liveEnergy by (detector?.liveEnergy?.collectAsState(initial = 0f)
        ?: remember { mutableFloatStateOf(0f) })

    var estimatedIntervalMs by remember { mutableLongStateOf(DEFAULT_INTERVAL_MS) }
    var nextBeatAt by remember { mutableLongStateOf(SystemClock.elapsedRealtime() + DEFAULT_INTERVAL_MS) }
    var lastRealBeatAt by remember { mutableLongStateOf(0L) }
    var hitFlash by remember { mutableFloatStateOf(0f) }
    var nowElapsed by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }

    // Resync to the real audio whenever a genuine beat is detected: refine the
    // tempo estimate and snap the next expected beat to actual playback.
    LaunchedEffect(detector) {
        val events = detector?.beatEvents ?: return@LaunchedEffect
        events.collect { t ->
            if (lastRealBeatAt != 0L) {
                val interval = t - lastRealBeatAt
                if (interval in 250..2000) {
                    estimatedIntervalMs = (estimatedIntervalMs * 0.6 + interval * 0.4).toLong()
                }
            }
            lastRealBeatAt = t
            nextBeatAt = t + estimatedIntervalMs
            hitFlash = 1f
        }
    }

    // Drives the animation every frame: advances the beat schedule on its own
    // when no fresh detection has arrived yet (so the bar never goes static),
    // and decays the hit flash after each pulse.
    LaunchedEffect(Unit) {
        while (true) {
            withFrameMillis { }
            val now = SystemClock.elapsedRealtime()
            nowElapsed = now
            while (now >= nextBeatAt) {
                nextBeatAt += estimatedIntervalMs
                hitFlash = 1f
            }
            hitFlash = (hitFlash - 0.045f).coerceAtLeast(0f)
        }
    }

    val idlePulse = 0.5f + 0.5f * sin(nowElapsed / 260f)
    val energyPulse = (liveEnergy * 1.4f).coerceIn(0f, 1f)

    Canvas(modifier = modifier.fillMaxSize()) {
        val hitX = size.width * HIT_X_FRACTION
        val centerY = size.height / 2f
        val laneColor = Color.White.copy(alpha = 0.12f)

        // Lane line the notes travel along.
        drawLine(
            color = laneColor,
            start = Offset(hitX, centerY),
            end = Offset(size.width, centerY),
            strokeWidth = 2.dp.toPx()
        )

        // Upcoming notes travelling from right to left toward the hit circle.
        for (k in 0 until VISIBLE_NOTES) {
            val targetAt = nextBeatAt + k * estimatedIntervalMs
            val startAt = targetAt - estimatedIntervalMs
            val progress = ((nowElapsed - startAt).toFloat() / estimatedIntervalMs).coerceIn(0f, 1f)
            val x = (size.width - hitX) * (1f - progress) + hitX
            val alpha = (1f - k * 0.3f).coerceAtLeast(0.15f) * (0.4f + 0.6f * progress)
            val radius = 8.dp.toPx() * (0.75f + 0.25f * progress)

            drawCircle(
                color = Color(0xFF00E5FF).copy(alpha = alpha),
                radius = radius,
                center = Offset(x, centerY)
            )
        }

        // The hit circle: a steady idle pulse driven by the music's loudness
        // (or a gentle decorative sway if there's no audio signal), plus a
        // sharp flash exactly on each beat.
        val baseRadius = 12.dp.toPx()
        val hitRadius = baseRadius * (1f + idlePulse * 0.1f + energyPulse * 0.25f + hitFlash * 0.6f)
        val hitColor = Color(0xFFFF4D8D)

        if (hitFlash > 0.05f) {
            drawCircle(
                color = hitColor.copy(alpha = hitFlash * 0.35f),
                radius = hitRadius + 14.dp.toPx() * hitFlash,
                center = Offset(hitX, centerY)
            )
        }
        drawCircle(
            color = hitColor.copy(alpha = 0.9f),
            radius = hitRadius,
            center = Offset(hitX, centerY)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.6f + hitFlash * 0.4f),
            radius = hitRadius,
            center = Offset(hitX, centerY),
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}
