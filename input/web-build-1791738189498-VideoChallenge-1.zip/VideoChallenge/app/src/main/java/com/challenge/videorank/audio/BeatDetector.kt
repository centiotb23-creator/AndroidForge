package com.challenge.videorank.audio

import android.media.audiofx.Visualizer
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.sqrt

/**
 * Listens to the real audio of whatever is currently playing in [audioSessionId]
 * (the level's video) and turns it into two things the beat bar can react to:
 *
 * - [liveEnergy]: a smoothed 0..1 loudness value, for a subtle continuous pulse.
 * - [beatEvents]: a timestamp (from [SystemClock.elapsedRealtime]) each time a
 *   loud, sudden spike in the low end is detected — a simple adaptive onset
 *   detector, not a studio-grade BPM analyzer, but it reacts convincingly to
 *   real kicks/snares in most music.
 *
 * Visualizer isn't available on every device/session, so [start] fails silently:
 * the beat bar just falls back to a steady decorative pulse instead of crashing.
 */
class BeatDetector(private val audioSessionId: Int) {

    private var visualizer: Visualizer? = null

    private val _liveEnergy = MutableStateFlow(0f)
    val liveEnergy: StateFlow<Float> = _liveEnergy

    private val _beatEvents = MutableSharedFlow<Long>(extraBufferCapacity = 8)
    val beatEvents: SharedFlow<Long> = _beatEvents

    private var runningAverage = 0f
    private var lastBeatAt = 0L

    /** Minimum gap between detected beats, so one loud hit doesn't fire a burst of events. */
    private val minBeatGapMs = 260L

    fun start() {
        if (audioSessionId == 0) return
        try {
            val visualizer = Visualizer(audioSessionId)
            val maxCapture = Visualizer.getCaptureSizeRange().getOrNull(1) ?: 1024
            visualizer.captureSize = maxCapture.coerceAtMost(1024)
            visualizer.setDataCaptureListener(
                object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(
                        v: Visualizer?,
                        waveform: ByteArray?,
                        samplingRate: Int
                    ) {
                        waveform?.let(::onWaveform)
                    }

                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                        // Not used: the raw waveform's RMS is enough for a convincing beat pulse
                        // and is much cheaper than decoding the FFT bins per frame.
                    }
                },
                (Visualizer.getMaxCaptureRate() / 2).coerceAtLeast(10000),
                true,
                false
            )
            visualizer.enabled = true
            this.visualizer = visualizer
        } catch (e: Exception) {
            // Some devices/sessions refuse Visualizer; the beat bar degrades gracefully.
            visualizer = null
        }
    }

    private fun onWaveform(waveform: ByteArray) {
        var sumSq = 0.0
        for (b in waveform) {
            val centered = (b.toInt() and 0xFF) - 128
            sumSq += (centered * centered).toDouble()
        }
        val rms = (sqrt(sumSq / waveform.size) / 128.0).toFloat().coerceIn(0f, 1f)

        _liveEnergy.value = _liveEnergy.value * 0.7f + rms * 0.3f

        runningAverage = runningAverage * 0.9f + rms * 0.1f
        val now = SystemClock.elapsedRealtime()
        val isSpike = rms > runningAverage * 1.35f + 0.02f
        if (isSpike && now - lastBeatAt > minBeatGapMs) {
            lastBeatAt = now
            _beatEvents.tryEmit(now)
        }
    }

    fun stop() {
        try {
            visualizer?.enabled = false
            visualizer?.release()
        } catch (e: Exception) {
            // Already released or never started; nothing to clean up.
        }
        visualizer = null
    }
}
