package com.challenge.videorank.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * A precomputed rhythm map for one specific video's real audio track.
 *
 * Instead of just picking out loud moments, the analysis estimates the
 * actual tempo (BPM) of the music in short windows across the track — using
 * autocorrelation of the loudness-change signal, the same idea a DJ's
 * beat-matcher uses — and lays down a steady, phase-aligned grid locked to
 * that tempo. That grid is what makes the result playable: a player can
 * learn and anticipate it, instead of chasing noise.
 *
 * Three nested grids are kept, one beat apart in subdivision:
 * - [quarterBeatsMs]: the main pulse (one dot per beat) — calm, easy to read.
 * - [eighthBeatsMs]: twice as dense (includes every quarter beat too).
 * - [sixteenthBeatsMs]: four times as dense (includes every eighth beat too).
 *
 * Which one gets used is a difficulty choice (denser grid = harder level),
 * made by the caller — the map itself just reflects the real song.
 */
data class BeatMap(
    val durationMs: Long,
    val quarterBeatsMs: LongArray,
    val eighthBeatsMs: LongArray,
    val sixteenthBeatsMs: LongArray,
    val intensityCurve: FloatArray,
    val intensityHopMs: Long
) {
    fun intensityAt(positionMs: Long): Float {
        if (intensityCurve.isEmpty()) return 0f
        val idx = (positionMs / intensityHopMs).toInt().coerceIn(0, intensityCurve.size - 1)
        return intensityCurve[idx]
    }
}

/** The next [count] timestamps in this (sorted) grid at or after [positionMs]. */
fun LongArray.from(positionMs: Long, count: Int): List<Long> {
    if (isEmpty()) return emptyList()
    val startIdx = binarySearch(positionMs).let { if (it < 0) -(it + 1) else it }
    if (startIdx >= size) return emptyList()
    return (startIdx until min(size, startIdx + count)).map { this[it] }
}

/** The timestamp in this (sorted) grid at or immediately before [positionMs], if any. */
fun LongArray.atOrBefore(positionMs: Long): Long? {
    if (isEmpty()) return null
    var idx = binarySearch(positionMs)
    if (idx < 0) idx = -(idx + 1) - 1
    return if (idx in indices) this[idx] else null
}

/**
 * Decodes a video's real audio track once, estimates its tempo over time,
 * and builds the nested beat grids from that — a proper offline analysis
 * specific to whatever video the person assigned to that level. Results are
 * cached to disk, so the decode only happens the first time.
 */
object BeatMapAnalyzer {

    /** Analysis resolution: a window every 25ms is fine enough to catch real onsets. */
    private const val HOP_MS = 25L

    /**
     * Tempo is re-estimated every 4s of audio — short enough to actually
     * notice a song speeding up or slowing down partway through, long enough
     * to still get a confident autocorrelation reading.
     */
    private const val SEGMENT_MS = 4000L

    private const val MIN_BPM = 70f
    private const val MAX_BPM = 190f
    private const val DEFAULT_PERIOD_MS = 500L // ~120 BPM, used only if nothing can be estimated at all

    /** How far around a candidate beat to look when deciding if it lands in silence. */
    private const val SILENCE_CHECK_WINDOW_MS = 70L

    private val memoryCache = mutableMapOf<String, BeatMap?>()

    suspend fun analyze(context: Context, uri: Uri, cacheKey: String): BeatMap? =
        withContext(Dispatchers.Default) {
            if (memoryCache.containsKey(cacheKey)) return@withContext memoryCache[cacheKey]

            loadFromDisk(context, cacheKey)?.let {
                memoryCache[cacheKey] = it
                return@withContext it
            }

            val map = try {
                decodeAndAnalyze(context, uri)
            } catch (e: Exception) {
                Log.w("BeatMapAnalyzer", "Could not analyze audio for $uri, falling back", e)
                null
            }
            memoryCache[cacheKey] = map
            if (map != null) saveToDisk(context, cacheKey, map)
            map
        }

    private fun decodeAndAnalyze(context: Context, uri: Uri): BeatMap? {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)

        var audioTrack = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                audioTrack = i
                format = f
                break
            }
        }
        if (audioTrack < 0 || format == null) {
            extractor.release()
            return null
        }
        extractor.selectTrack(audioTrack)

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE))
            format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
        val channelCount = (if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT))
            format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1).coerceAtLeast(1)

        val hopSamples = max(1, (sampleRate * HOP_MS / 1000).toInt())
        var samplesInWindow = 0
        var sumSq = 0.0

        val intensityList = ArrayList<Float>(4096)
        // Onset-strength envelope: positive jumps in loudness, one value per hop.
        // This is what the tempo estimate and the beat grid are both built from.
        val fluxList = ArrayList<Float>(4096)
        var prevRms = 0f

        val bufferInfo = MediaCodec.BufferInfo()
        var sawInputEof = false
        var sawOutputEof = false
        var totalDurationUs = 0L

        // Cap analysis so a very long import still finishes quickly; most
        // personal-clip challenges are well under this anyway.
        val maxDurationUs = 6L * 60L * 1_000_000L

        while (!sawOutputEof) {
            if (!sawInputEof) {
                val inIndex = codec.dequeueInputBuffer(10_000)
                if (inIndex >= 0) {
                    val inBuffer = codec.getInputBuffer(inIndex)!!
                    val sampleSize = extractor.readSampleData(inBuffer, 0)
                    if (sampleSize < 0 || extractor.sampleTime > maxDurationUs) {
                        codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        sawInputEof = true
                    } else {
                        val presentationTimeUs = extractor.sampleTime
                        totalDurationUs = max(totalDurationUs, presentationTimeUs)
                        codec.queueInputBuffer(inIndex, 0, sampleSize, presentationTimeUs, 0)
                        extractor.advance()
                    }
                }
            }

            val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
            if (outIndex >= 0) {
                val outBuffer = codec.getOutputBuffer(outIndex)
                if (outBuffer != null && bufferInfo.size > 0) {
                    outBuffer.position(bufferInfo.offset)
                    outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                    val totalShorts = bufferInfo.size / 2

                    var consumed = 0
                    while (consumed + channelCount <= totalShorts && outBuffer.remaining() >= channelCount * 2) {
                        var frameSum = 0
                        for (c in 0 until channelCount) {
                            val lo = outBuffer.get().toInt() and 0xFF
                            val hi = outBuffer.get().toInt()
                            frameSum += (hi shl 8) or lo
                        }
                        consumed += channelCount
                        val mono = (frameSum / channelCount).toFloat()
                        sumSq += (mono * mono).toDouble()
                        samplesInWindow++
                        if (samplesInWindow >= hopSamples) {
                            val rms = (sqrt(sumSq / samplesInWindow) / 32768.0).toFloat().coerceIn(0f, 1f)
                            intensityList.add(rms)
                            fluxList.add((rms - prevRms).coerceAtLeast(0f))
                            prevRms = rms
                            sumSq = 0.0
                            samplesInWindow = 0
                        }
                    }
                }
                codec.releaseOutputBuffer(outIndex, false)
                if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                    sawOutputEof = true
                }
            }
        }

        try {
            codec.stop()
        } catch (e: Exception) { /* already stopped */ }
        codec.release()
        extractor.release()

        if (intensityList.isEmpty()) return null

        val intensityArray = intensityList.toFloatArray()
        val (quarter, eighth, sixteenth) = buildBeatGrids(fluxList, HOP_MS)

        // Drop any grid point that lands where the track is actually quiet —
        // a real pause, a silent intro, the gap between songs in a mashup —
        // instead of letting the tempo estimate tick on through it. The
        // threshold is relative to this specific track's own average
        // loudness, so it adapts instead of using one fixed volume for every
        // video.
        val silenceThreshold = silenceThresholdFor(intensityArray)
        fun audible(grid: LongArray) = grid.filter {
            isAudibleAt(intensityArray, HOP_MS, it, silenceThreshold)
        }.toLongArray()

        return BeatMap(
            durationMs = totalDurationUs / 1000L,
            quarterBeatsMs = audible(quarter),
            eighthBeatsMs = audible(eighth),
            sixteenthBeatsMs = audible(sixteenth),
            intensityCurve = intensityArray,
            intensityHopMs = HOP_MS
        )
    }

    /**
     * A per-track loudness floor below which a moment counts as "silence" for
     * beat purposes: a fraction of that track's own average level (so a
     * quiet acoustic clip and a loud, compressed one are each judged against
     * themselves), with a small absolute floor so a genuinely silent track
     * doesn't produce a near-zero threshold that lets noise floor through.
     */
    private fun silenceThresholdFor(intensity: FloatArray): Float {
        if (intensity.isEmpty()) return 0.02f
        var sum = 0f
        for (v in intensity) sum += v
        val average = sum / intensity.size
        return (average * 0.24f).coerceAtLeast(0.015f)
    }

    private fun isAudibleAt(intensity: FloatArray, hopMs: Long, atMs: Long, threshold: Float): Boolean {
        if (intensity.isEmpty()) return false
        val centerIdx = (atMs / hopMs).toInt().coerceIn(0, intensity.size - 1)
        val windowHops = max(1, (SILENCE_CHECK_WINDOW_MS / hopMs).toInt())
        val from = (centerIdx - windowHops).coerceAtLeast(0)
        val to = (centerIdx + windowHops).coerceAtMost(intensity.size - 1)
        var sum = 0f
        for (i in from..to) sum += intensity[i]
        val localAverage = sum / (to - from + 1)
        return localAverage >= threshold
    }

    /**
     * Walks the track in a few seconds at a time, estimates the dominant
     * tempo and beat phase in each window via autocorrelation of the onset
     * envelope, and lays down three nested grids locked to that tempo. If a
     * window is too quiet/short to get a confident estimate, it keeps the
     * previous window's tempo going rather than guessing randomly, so the
     * grid never jumps around on its own.
     */
    private fun buildBeatGrids(flux: List<Float>, hopMs: Long): Triple<LongArray, LongArray, LongArray> {
        val quarter = ArrayList<Long>()
        val eighth = ArrayList<Long>()
        val sixteenth = ArrayList<Long>()

        val segmentHopCount = max(1, (SEGMENT_MS / hopMs).toInt())
        var carryPeriodMs: Long? = null
        var carryAnchorMs: Long? = null

        var segStartIdx = 0
        while (segStartIdx < flux.size) {
            val segEndIdx = min(flux.size, segStartIdx + segmentHopCount)
            val segStartMs = segStartIdx * hopMs
            val segEndMs = segEndIdx * hopMs

            val estimate = estimateTempo(flux, segStartIdx, segEndIdx, hopMs)
            val periodMs: Long
            val anchorMs: Long
            if (estimate != null) {
                periodMs = estimate.first
                anchorMs = segStartMs + estimate.second
            } else if (carryPeriodMs != null && carryAnchorMs != null) {
                // Keep the previous tempo going through a quiet/ambiguous patch
                // instead of inventing a new, disconnected one.
                periodMs = carryPeriodMs
                val k = ceil((segStartMs - carryAnchorMs).toDouble() / periodMs).toLong()
                anchorMs = carryAnchorMs + k * periodMs
            } else {
                periodMs = DEFAULT_PERIOD_MS
                anchorMs = segStartMs
            }
            carryPeriodMs = periodMs
            carryAnchorMs = anchorMs

            appendGrid(quarter, anchorMs, periodMs, segStartMs, segEndMs)
            appendGrid(eighth, anchorMs, periodMs / 2, segStartMs, segEndMs)
            appendGrid(sixteenth, anchorMs, periodMs / 4, segStartMs, segEndMs)

            segStartIdx = segEndIdx
        }

        return Triple(quarter.toLongArray(), eighth.toLongArray(), sixteenth.toLongArray())
    }

    private fun appendGrid(out: MutableList<Long>, anchorMs: Long, step: Long, fromMs: Long, toMs: Long) {
        if (step <= 0) return
        val k = ceil((fromMs - anchorMs).toDouble() / step).toLong()
        var t = anchorMs + k * step
        while (t < toMs) {
            out.add(t)
            t += step
        }
    }

    /**
     * Autocorrelation tempo estimate over one window: for each candidate beat
     * period in the musically plausible range, scores how well the onset
     * envelope lines up with itself one period later, and keeps the best
     * match. Then finds the phase (where in the window the beat actually
     * falls) by testing which offset best lines up with the real energy
     * spikes. Returns null if the window is too short or too flat/quiet to
     * say anything meaningful.
     */
    private fun estimateTempo(flux: List<Float>, fromIdx: Int, toIdx: Int, hopMs: Long): Pair<Long, Long>? {
        val minPeriodMs = (60_000f / MAX_BPM).toLong()
        val maxPeriodMs = (60_000f / MIN_BPM).toLong()
        val minLag = max(1, (minPeriodMs / hopMs).toInt())
        val maxLag = (maxPeriodMs / hopMs).toInt()
        val length = toIdx - fromIdx
        if (length < maxLag * 2) return null

        var totalEnergy = 0f
        for (i in fromIdx until toIdx) totalEnergy += flux[i]
        if (totalEnergy < length * 0.004f) return null // effectively silent window

        var bestLag = -1
        var bestScore = -1f
        for (lag in minLag..maxLag) {
            var sum = 0f
            var count = 0
            var i = fromIdx
            while (i < toIdx - lag) {
                sum += flux[i] * flux[i + lag]
                count++
                i++
            }
            if (count == 0) continue
            val score = sum / count
            if (score > bestScore) {
                bestScore = score
                bestLag = lag
            }
        }
        if (bestLag <= 0 || bestScore <= 0f) return null

        var bestPhase = 0
        var bestPhaseScore = -1f
        for (offset in 0 until bestLag) {
            var sum = 0f
            var idx = fromIdx + offset
            while (idx < toIdx) {
                sum += flux[idx]
                idx += bestLag
            }
            if (sum > bestPhaseScore) {
                bestPhaseScore = sum
                bestPhase = offset
            }
        }

        return (bestLag * hopMs) to (bestPhase * hopMs)
    }

    private fun cacheFile(context: Context, cacheKey: String): File =
        File(context.cacheDir, "beatmaps").apply { mkdirs() }.resolve("$cacheKey.json")

    private fun loadFromDisk(context: Context, cacheKey: String): BeatMap? = try {
        val file = cacheFile(context, cacheKey)
        if (!file.exists()) null else {
            val json = JSONObject(file.readText())
            fun longArrayFrom(key: String): LongArray {
                val arr = json.getJSONArray(key)
                return LongArray(arr.length()) { arr.getLong(it) }
            }
            val intensityJson = json.getJSONArray("intensity")
            val intensity = FloatArray(intensityJson.length()) { intensityJson.getDouble(it).toFloat() }
            BeatMap(
                durationMs = json.getLong("durationMs"),
                quarterBeatsMs = longArrayFrom("quarter"),
                eighthBeatsMs = longArrayFrom("eighth"),
                sixteenthBeatsMs = longArrayFrom("sixteenth"),
                intensityCurve = intensity,
                intensityHopMs = json.getLong("intensityHopMs")
            )
        }
    } catch (e: Exception) {
        null
    }

    private fun saveToDisk(context: Context, cacheKey: String, map: BeatMap) {
        try {
            val json = JSONObject()
            json.put("durationMs", map.durationMs)
            json.put("quarter", JSONArray(map.quarterBeatsMs.toList()))
            json.put("eighth", JSONArray(map.eighthBeatsMs.toList()))
            json.put("sixteenth", JSONArray(map.sixteenthBeatsMs.toList()))
            json.put("intensity", JSONArray(map.intensityCurve.toList()))
            json.put("intensityHopMs", map.intensityHopMs)
            cacheFile(context, cacheKey).writeText(json.toString())
        } catch (e: Exception) {
            // Cache is an optimization; losing it just means re-analyzing next time.
        }
    }

    fun cacheKeyFor(uri: Uri): String {
        val digest = MessageDigest.getInstance("MD5").digest(uri.toString().toByteArray())
        return digest.joinToString("") { "%02x".format(it) } + "-v3"
    }
}
