package com.challenge.videorank.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.challenge.videorank.data.VideoEntity
import com.challenge.videorank.ui.components.colorForLevel
import com.challenge.videorank.ui.theme.BackgroundDark
import com.challenge.videorank.ui.theme.NeonCyan
import com.challenge.videorank.ui.theme.SurfaceDark
import com.challenge.videorank.util.VideoUtils
import com.challenge.videorank.viewmodel.GameViewModel
import com.challenge.videorank.viewmodel.TOTAL_LEVELS

@Composable
fun LevelEditorScreen(viewModel: GameViewModel, onBack: () -> Unit) {
    val videos by viewModel.videos.collectAsState()
    var pickerForLevel by remember { mutableStateOf<Int?>(null) }
    val configured = videos.count { it.level != null }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BackgroundDark, Color(0xFF1A1033))))
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = Color.White)
                }
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("CONFIGURA TUS NIVELES", color = NeonCyan, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text(
                        "$configured / $TOTAL_LEVELS niveles asignados",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            if (videos.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Importa vídeos desde la pantalla principal\npara poder asignarlos a un nivel",
                        color = Color.White.copy(alpha = 0.6f)
                    )
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(1..TOTAL_LEVELS, key = { it }) { level ->
                        val assigned = videos.firstOrNull { it.level == level }
                        LevelSlotRow(
                            level = level,
                            video = assigned,
                            viewModel = viewModel,
                            onAssignClick = { pickerForLevel = level },
                            onRemoveClick = { viewModel.unassignLevel(level) }
                        )
                    }
                }
            }
        }
    }

    val activeLevel = pickerForLevel
    if (activeLevel != null) {
        VideoPickerDialog(
            level = activeLevel,
            videos = videos,
            viewModel = viewModel,
            onDismiss = { pickerForLevel = null },
            onSelect = { video ->
                viewModel.assignVideoToLevel(video, activeLevel)
                pickerForLevel = null
            }
        )
    }
}

@Composable
private fun LevelSlotRow(
    level: Int,
    video: VideoEntity?,
    viewModel: GameViewModel,
    onAssignClick: () -> Unit,
    onRemoveClick: () -> Unit
) {
    val levelColor = colorForLevel(level)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 72.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceDark)
            .border(1.dp, levelColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .clickable { onAssignClick() }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(levelColor.copy(alpha = 0.2f), CircleShape)
                .border(1.dp, levelColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("$level", color = levelColor, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        }

        Spacer(Modifier.width(12.dp))

        if (video == null) {
            Text(
                "Toca para asignar un vídeo",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 13.sp,
                modifier = Modifier.weight(1f)
            )
        } else {
            var thumbnail by remember(video.id) { mutableStateOf<Bitmap?>(null) }
            LaunchedEffect(video.id) {
                thumbnail = viewModel.thumbnailFor(video)
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black)
            ) {
                thumbnail?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = video.displayName,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(video.displayName, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
                Text(VideoUtils.formatDuration(video.durationMs), color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
            }
            IconButton(onClick = onRemoveClick) {
                Icon(Icons.Filled.Close, contentDescription = "Quitar", tint = Color.White.copy(alpha = 0.6f))
            }
        }
    }
}

@Composable
private fun VideoPickerDialog(
    level: Int,
    videos: List<VideoEntity>,
    viewModel: GameViewModel,
    onDismiss: () -> Unit,
    onSelect: (VideoEntity) -> Unit
) {
    val levelColor = colorForLevel(level)
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 480.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceDark)
                .border(1.dp, levelColor, RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Elige el vídeo del nivel $level",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(videos, key = { it.id }) { video ->
                        PickerRow(video = video, viewModel = viewModel, onClick = { onSelect(video) })
                    }
                }
            }
        }
    }
}

@Composable
private fun PickerRow(video: VideoEntity, viewModel: GameViewModel, onClick: () -> Unit) {
    var thumbnail by remember(video.id) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(video.id) {
        thumbnail = viewModel.thumbnailFor(video)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF261F47))
            .clickable { onClick() }
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.Black)
        ) {
            thumbnail?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = video.displayName,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(video.displayName, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
            Text(VideoUtils.formatDuration(video.durationMs), color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
        }
        if (video.level != null) {
            Box(
                modifier = Modifier
                    .background(colorForLevel(video.level).copy(alpha = 0.2f), RoundedCornerShape(50))
                    .border(1.dp, colorForLevel(video.level), RoundedCornerShape(50))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("Nivel ${video.level}", color = colorForLevel(video.level), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
